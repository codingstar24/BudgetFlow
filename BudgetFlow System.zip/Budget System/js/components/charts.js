/* ============================================
   CHARTS — Chart.js Wrapper Functions
   ============================================ */

const Charts = {
  instances: {},

  getThemeColors() {
    const s = getComputedStyle(document.documentElement);
    return {
      text: s.getPropertyValue('--chart-text').trim() || '#868e96',
      grid: s.getPropertyValue('--chart-grid').trim() || '#f1f3f5',
      accent: s.getPropertyValue('--accent').trim() || '#4361ee',
      success: s.getPropertyValue('--success').trim() || '#2d9c5a',
      danger: s.getPropertyValue('--danger').trim() || '#dc3545',
      warning: s.getPropertyValue('--warning').trim() || '#e8a317',
      bg: s.getPropertyValue('--card-bg').trim() || '#ffffff'
    };
  },

  destroy(id) {
    if (this.instances[id]) {
      this.instances[id].destroy();
      delete this.instances[id];
    }
  },

  destroyAll() {
    Object.keys(this.instances).forEach(id => this.destroy(id));
  },

  // Doughnut chart for category spending
  doughnut(canvasId, labels, data, colors, options = {}) {
    this.destroy(canvasId);
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    const theme = this.getThemeColors();

    this.instances[canvasId] = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: colors,
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 16,
              usePointStyle: true,
              pointStyle: 'circle',
              font: { size: 12, family: 'Inter, sans-serif' },
              color: theme.text
            }
          },
          tooltip: {
            backgroundColor: theme.bg,
            titleColor: theme.text,
            bodyColor: theme.text,
            borderColor: theme.grid,
            borderWidth: 1,
            padding: 12,
            cornerRadius: 8,
            bodyFont: { family: 'Inter, sans-serif' },
            callbacks: {
              label: function(ctx) {
                return ` ${ctx.label}: ${Utils.formatCurrency(ctx.raw)}`;
              }
            }
          }
        },
        ...options
      }
    });
  },

  // Bar chart
  bar(canvasId, labels, datasets, options = {}) {
    this.destroy(canvasId);
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    const theme = this.getThemeColors();

    this.instances[canvasId] = new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: datasets.length > 1,
            position: 'top',
            labels: {
              padding: 16,
              usePointStyle: true,
              pointStyle: 'circle',
              font: { size: 12, family: 'Inter, sans-serif' },
              color: theme.text
            }
          },
          tooltip: {
            backgroundColor: theme.bg,
            titleColor: theme.text,
            bodyColor: theme.text,
            borderColor: theme.grid,
            borderWidth: 1,
            padding: 12,
            cornerRadius: 8,
            bodyFont: { family: 'Inter, sans-serif' },
            callbacks: {
              label: function(ctx) {
                return ` ${ctx.dataset.label}: ${Utils.formatCurrency(ctx.raw)}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 11, family: 'Inter, sans-serif' }, color: theme.text }
          },
          y: {
            grid: { color: theme.grid, lineWidth: 0.5 },
            ticks: {
              font: { size: 11, family: 'Inter, sans-serif' },
              color: theme.text,
              callback: (v) => Utils.formatCurrencyShort(v)
            },
            beginAtZero: true
          }
        },
        borderRadius: 6,
        barPercentage: 0.6,
        ...options
      }
    });
  },

  // Line chart
  line(canvasId, labels, datasets, options = {}) {
    this.destroy(canvasId);
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;
    const theme = this.getThemeColors();

    this.instances[canvasId] = new Chart(ctx, {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: datasets.length > 1,
            position: 'top',
            labels: {
              padding: 16,
              usePointStyle: true,
              pointStyle: 'circle',
              font: { size: 12, family: 'Inter, sans-serif' },
              color: theme.text
            }
          },
          tooltip: {
            backgroundColor: theme.bg,
            titleColor: theme.text,
            bodyColor: theme.text,
            borderColor: theme.grid,
            borderWidth: 1,
            padding: 12,
            cornerRadius: 8,
            bodyFont: { family: 'Inter, sans-serif' },
            intersect: false,
            mode: 'index',
            callbacks: {
              label: function(ctx) {
                return ` ${ctx.dataset.label}: ${Utils.formatCurrency(ctx.raw)}`;
              }
            }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 11, family: 'Inter, sans-serif' }, color: theme.text }
          },
          y: {
            grid: { color: theme.grid, lineWidth: 0.5 },
            ticks: {
              font: { size: 11, family: 'Inter, sans-serif' },
              color: theme.text,
              callback: (v) => Utils.formatCurrencyShort(v)
            },
            beginAtZero: true
          }
        },
        interaction: { intersect: false, mode: 'index' },
        ...options
      }
    });
  },

  // Progress circle SVG
  progressCircle(percent, size = 80, strokeWidth = 6, color = '') {
    const r = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * r;
    const offset = circumference - (percent / 100) * circumference;
    const accentColor = color || 'var(--accent)';

    return `
      <div class="progress-circle" style="width:${size}px;height:${size}px">
        <svg width="${size}" height="${size}">
          <circle class="progress-circle-track" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="${strokeWidth}"/>
          <circle class="progress-circle-fill" cx="${size/2}" cy="${size/2}" r="${r}" stroke-width="${strokeWidth}"
            stroke="${accentColor}" stroke-dasharray="${circumference}" stroke-dashoffset="${offset}"/>
        </svg>
        <span class="progress-circle-text">${Math.round(percent)}%</span>
      </div>
    `;
  }
};
