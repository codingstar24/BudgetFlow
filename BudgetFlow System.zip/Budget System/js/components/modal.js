/* ============================================
   MODAL — Reusable Modal Component
   ============================================ */

const Modal = {
  stack: [],

  open({ title, content, footer, size = '', onClose = null, id = '' }) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.id = id || 'modal-' + Date.now();

    const sizeClass = size === 'lg' ? 'modal-lg' : '';

    overlay.innerHTML = `
      <div class="modal ${sizeClass}">
        <div class="modal-header">
          <h3 class="modal-title">${title}</h3>
          <button class="modal-close" data-close-modal>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div class="modal-body">${content}</div>
        ${footer ? `<div class="modal-footer">${footer}</div>` : ''}
      </div>
    `;

    document.body.appendChild(overlay);
    this.stack.push({ overlay, onClose });

    // Animate in
    requestAnimationFrame(() => {
      overlay.classList.add('active');
    });

    // Close handlers
    overlay.querySelector('[data-close-modal]').addEventListener('click', () => this.close());
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) this.close();
    });

    // Escape key
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        this.close();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);

    return overlay;
  },

  close(id) {
    let entry;
    if (id) {
      const idx = this.stack.findIndex(s => s.overlay.id === id);
      if (idx >= 0) {
        entry = this.stack.splice(idx, 1)[0];
      }
    } else {
      entry = this.stack.pop();
    }

    if (entry) {
      entry.overlay.classList.remove('active');
      setTimeout(() => {
        entry.overlay.remove();
        entry.onClose?.();
      }, 200);
    }
  },

  closeAll() {
    while (this.stack.length) this.close();
  },

  confirm({ title, message, confirmText = 'Delete', confirmClass = 'btn-danger', icon = 'danger' }) {
    return new Promise((resolve) => {
      const iconSvg = icon === 'danger'
        ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;

      const content = `
        <div class="confirm-dialog-icon ${icon}">
          ${iconSvg}
        </div>
        <h3 class="confirm-dialog-text" style="font-size:var(--text-lg);font-weight:var(--weight-semibold);color:var(--text-primary)">${title}</h3>
        <p class="confirm-dialog-text" style="font-size:var(--text-base);color:var(--text-tertiary);margin-bottom:var(--space-4)">${message}</p>
      `;

      const footer = `
        <button class="btn btn-secondary" data-close-modal>Cancel</button>
        <button class="btn ${confirmClass}" id="confirm-action-btn">${confirmText}</button>
      `;

      const overlay = this.open({ title: '', content, footer, id: 'confirm-dialog' });
      overlay.querySelector('.modal-header').style.display = 'none';
      overlay.querySelector('.modal-body').style.textAlign = 'center';

      overlay.querySelector('#confirm-action-btn').addEventListener('click', () => {
        this.close('confirm-dialog');
        resolve(true);
      });

      overlay.querySelector('.modal-footer [data-close-modal]').addEventListener('click', () => {
        resolve(false);
      });

      // Override backdrop close
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) resolve(false);
      });
    });
  }
};
