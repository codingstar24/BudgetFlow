/* ============================================
   SKELETON — Loading Placeholder Generator
   ============================================ */

const Skeleton = {
  card(count = 1) {
    return Array(count).fill(`
      <div class="skeleton skeleton-card">
        <div class="skeleton skeleton-title"></div>
        <div class="skeleton skeleton-text"></div>
        <div class="skeleton skeleton-text"></div>
        <div class="skeleton skeleton-text" style="width:40%"></div>
      </div>
    `).join('');
  },

  summaryCards(count = 5) {
    return Array(count).fill(`
      <div class="summary-card">
        <div class="skeleton skeleton-circle" style="width:40px;height:40px"></div>
        <div class="skeleton skeleton-text" style="width:60%;height:24px"></div>
        <div class="skeleton skeleton-text" style="width:40%"></div>
      </div>
    `).join('');
  },

  tableRows(count = 5) {
    return Array(count).fill(`
      <tr>
        <td><div class="skeleton skeleton-text" style="width:80%"></div></td>
        <td><div class="skeleton skeleton-text" style="width:60%"></div></td>
        <td><div class="skeleton skeleton-text" style="width:50%"></div></td>
        <td><div class="skeleton skeleton-text" style="width:70%"></div></td>
        <td><div class="skeleton skeleton-text" style="width:40%"></div></td>
      </tr>
    `).join('');
  },

  chart() {
    return `
      <div style="display:flex;align-items:center;justify-content:center;height:200px">
        <div class="skeleton" style="width:160px;height:160px;border-radius:50%"></div>
      </div>
    `;
  },

  list(count = 5) {
    return Array(count).fill(`
      <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border-light)">
        <div class="skeleton" style="width:36px;height:36px;border-radius:8px;flex-shrink:0"></div>
        <div style="flex:1">
          <div class="skeleton skeleton-text" style="width:60%"></div>
          <div class="skeleton skeleton-text" style="width:30%"></div>
        </div>
        <div class="skeleton" style="width:60px;height:16px"></div>
      </div>
    `).join('');
  }
};
