/* ============================================
   TOPBAR — Search, Quick Add, Theme Toggle
   ============================================ */

const Topbar = {
  render() {
    const topbar = document.getElementById('topbar');
    if (!topbar) return;

    topbar.innerHTML = `
      <div class="topbar-left">
        <button class="topbar-hamburger" id="mobile-menu-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>
          </svg>
        </button>
        <h1 class="topbar-title" id="topbar-title">Dashboard</h1>
      </div>

      <div class="topbar-search">
        <div class="topbar-search-wrapper">
          <svg class="topbar-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input type="text" class="topbar-search-input" id="global-search" placeholder="Search transactions..." autocomplete="off">
          <div class="search-results hidden" id="global-search-results"></div>
        </div>
      </div>

      <div class="topbar-right">
        <div class="topbar-quick-actions">
          <button class="btn btn-sm btn-success" id="quick-add-income" data-tooltip="Add Income">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Income
          </button>
          <button class="btn btn-sm btn-danger" id="quick-add-expense" data-tooltip="Add Expense">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Expense
          </button>
        </div>

        <button class="topbar-btn" id="theme-toggle" data-tooltip="Toggle theme">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
          </svg>
        </button>
      </div>
    `;

    this.bindEvents();
  },

  bindEvents() {
    // Mobile menu
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
      const sidebar = document.getElementById('sidebar');
      const overlay = document.getElementById('sidebar-overlay');
      sidebar?.classList.toggle('mobile-open');
      overlay?.classList.toggle('visible');
    });

    // Theme toggle
    document.getElementById('theme-toggle')?.addEventListener('click', () => {
      Theme.toggle();
    });

    // Quick add buttons
    document.getElementById('quick-add-income')?.addEventListener('click', () => {
      TransactionService.openAddModal('income');
    });

    document.getElementById('quick-add-expense')?.addEventListener('click', () => {
      TransactionService.openAddModal('expense');
    });

    // Global search
    const searchInput = document.getElementById('global-search');
    const searchResults = document.getElementById('global-search-results');

    if (searchInput) {
      searchInput.addEventListener('input', Utils.debounce(async (e) => {
        const query = e.target.value.trim().toLowerCase();
        if (query.length < 2) {
          searchResults?.classList.add('hidden');
          return;
        }

        try {
          const txs = await db.transactions
            .filter(tx => tx.title?.toLowerCase().includes(query) || tx.notes?.toLowerCase().includes(query))
            .limit(8)
            .toArray();

          if (txs.length === 0) {
            searchResults.innerHTML = `<div class="search-result-item" style="color:var(--text-tertiary)">No results found</div>`;
          } else {
            searchResults.innerHTML = txs.map(tx => `
              <div class="search-result-item" onclick="Router.navigate('transactions');document.getElementById('global-search').value='';document.getElementById('global-search-results').classList.add('hidden');">
                <div style="flex:1">
                  <div style="font-weight:500;color:var(--text-primary)">${Utils.escapeHtml(tx.title)}</div>
                  <div style="font-size:var(--text-xs);color:var(--text-tertiary)">${Utils.formatDate(tx.date)} • ${tx.category || ''}</div>
                </div>
                <span class="amount ${tx.type}">${tx.type === 'income' ? '+' : '-'}${Utils.formatCurrency(tx.amount)}</span>
              </div>
            `).join('');
          }

          searchResults?.classList.remove('hidden');
        } catch (e) {
          console.error('Search error:', e);
        }
      }, 250));

      // Close search on outside click
      document.addEventListener('click', (e) => {
        if (!e.target.closest('.topbar-search')) {
          searchResults?.classList.add('hidden');
        }
      });

      // Close on Escape
      searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          searchInput.value = '';
          searchResults?.classList.add('hidden');
          searchInput.blur();
        }
      });
    }
  }
};
