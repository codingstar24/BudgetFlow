/* ============================================
   DATABASE — Dexie.js IndexedDB Setup
   ============================================ */

const db = new Dexie('BudgetTrackerDB');

db.version(1).stores({
  transactions: '++id, title, amount, type, category, date, paymentMethod, isRecurring, createdAt',
  categories: '++id, name, isDefault, createdAt',
  budgets: '++id, month, year, [month+year], createdAt',
  savingsGoals: '++id, name, createdAt',
  subscriptions: '++id, name, nextDueDate, isActive, createdAt',
  emis: '++id, name, nextDueDate, createdAt',
  trash: '++id, type, deletedAt',
  receipts: '++id, transactionId, generatedAt'
});

// Seed default categories on first run
async function seedDefaults() {
  const count = await db.categories.count();
  if (count === 0) {
    await db.categories.bulkAdd(DEFAULT_CATEGORIES.map(cat => ({
      ...cat,
      isDefault: true,
      createdAt: new Date().toISOString()
    })));
  }
}

// Initialize database
async function initDB() {
  try {
    await db.open();
    await seedDefaults();
    console.log('Database initialized successfully');
  } catch (err) {
    console.error('Database initialization failed:', err);
  }
}
