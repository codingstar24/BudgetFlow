/* ============================================
   REPORT SERVICE — Data Aggregation
   ============================================ */

const ReportService = {
  async getReport(startDate, endDate) {
    const allTxs = await db.transactions.toArray();
    const txs = allTxs.filter(t => t.date >= startDate && t.date <= endDate);

    const income = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const expenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);

    // Category breakdown
    const categorySpending = {};
    txs.filter(t => t.type === 'expense').forEach(t => {
      categorySpending[t.category || 'Other'] = (categorySpending[t.category || 'Other'] || 0) + t.amount;
    });

    // Daily breakdown
    const daily = {};
    txs.forEach(t => {
      if (!daily[t.date]) daily[t.date] = { income: 0, expense: 0 };
      daily[t.date][t.type] = (daily[t.date][t.type] || 0) + t.amount;
    });

    // Monthly trend (for yearly views)
    const monthly = {};
    txs.forEach(t => {
      const key = t.date?.substring(0, 7) || '';
      if (!monthly[key]) monthly[key] = { income: 0, expense: 0 };
      monthly[key][t.type] = (monthly[key][t.type] || 0) + t.amount;
    });

    // Payment method breakdown
    const paymentMethods = {};
    txs.filter(t => t.type === 'expense').forEach(t => {
      const method = t.paymentMethod || 'Other';
      paymentMethods[method] = (paymentMethods[method] || 0) + t.amount;
    });

    return {
      income, expenses,
      balance: income - expenses,
      transactions: txs,
      categorySpending,
      daily,
      monthly,
      paymentMethods,
      transactionCount: txs.length
    };
  },

  async getSavingsHistory() {
    const goals = await db.savingsGoals.toArray();
    return goals.map(g => ({
      name: g.name,
      saved: g.savedAmount,
      target: g.targetAmount,
      percent: Utils.percentage(g.savedAmount, g.targetAmount)
    }));
  },

  getDateRange(period) {
    const today = new Date();
    let startDate, endDate = Utils.today();

    switch (period) {
      case 'daily':
        startDate = endDate;
        break;
      case 'weekly':
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay());
        startDate = weekStart.toISOString().split('T')[0];
        break;
      case 'monthly':
        startDate = Utils.getMonthStart(Utils.getCurrentMonth(), Utils.getCurrentYear());
        break;
      case 'yearly':
        startDate = `${Utils.getCurrentYear()}-01-01`;
        break;
      default:
        startDate = Utils.getMonthStart(Utils.getCurrentMonth(), Utils.getCurrentYear());
    }

    return { startDate, endDate };
  }
};

/* ============================================
   PDF SERVICE — Receipt & Report PDFs
   ============================================ */

const PDFService = {

  // ── Currency formatter for PDF (jsPDF fonts don't support ₹) ──
  _currency(amount) {
    return Utils.formatCurrency(amount).replace('₹', 'Rs. ');
  },

  // ── Simple dashed line ──
  _dashed(doc, x1, y, x2) {
    doc.setDrawColor(180);
    doc.setLineWidth(0.2);
    const dash = 1.5, gap = 1.5;
    for (let x = x1; x < x2; x += dash + gap) {
      doc.line(x, y, Math.min(x + dash, x2), y);
    }
  },

  // ── Solid thin line ──
  _line(doc, y) {
    doc.setDrawColor(200);
    doc.setLineWidth(0.3);
    doc.line(20, y, 190, y);
  },

  // ── Simple key:value row  (left label, right value) ──
  _row(doc, y, label, value, options = {}) {
    doc.setFontSize(options.size || 9);

    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100);
    doc.text(label, 24, y);

    doc.setFont('helvetica', options.bold !== false ? 'bold' : 'normal');
    doc.setTextColor(...(options.color || [30, 30, 30]));
    doc.text(String(value), 186, y, { align: 'right' });

    return y + (options.gap || 7);
  },

  // ── Section header ──
  _section(doc, y, title) {
    this._line(doc, y);
    y += 7;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(50);
    doc.text(title.toUpperCase(), 24, y);
    y += 2;
    this._dashed(doc, 20, y, 190);
    return y + 6;
  },

  // ── Footer ──
  _footer(doc) {
    const ph = doc.internal.pageSize.getHeight();
    this._dashed(doc, 20, ph - 18, 190);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(140);
    doc.text('BudgetFlow  •  Personal Finance Tracker', 20, ph - 12);
    doc.text('Computer-generated receipt. No signature required.', 20, ph - 8);
    doc.text(new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }), 186, ph - 12, { align: 'right' });
  },


  // ═══════════════════════════════════════
  //  TRANSACTION RECEIPT
  // ═══════════════════════════════════════
  async generateReceipt(transaction) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const userName = localStorage.getItem('userName') || 'User';
    const receiptNo = Utils.generateReceiptNumber();
    const isIncome = transaction.type === 'income';

    // ── 1. HEADER ──
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(30);
    doc.text('BudgetFlow', 24, 20);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text('Personal Finance Receipt', 24, 26);

    // Right side — receipt label
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30);
    doc.text('RECEIPT', 186, 16, { align: 'right' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(`#${receiptNo}`, 186, 23, { align: 'right' });

    this._line(doc, 30);
    let y = 38;

    // ── 2. FROM / TO / DATE ROW ──
    // Three columns
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(130);
    doc.text('ISSUED TO', 24, y);
    doc.text('DATE & TIME', 90, y);
    doc.text('TRANSACTION ID', 150, y);

    y += 5;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30);
    doc.text(userName, 24, y);
    doc.text(`${Utils.formatDate(transaction.date)}  ${transaction.time ? Utils.formatTime(transaction.time) : ''}`, 90, y);

    doc.setFontSize(8);
    doc.text(transaction.transactionId || 'N/A', 150, y);
    y += 6;

    this._dashed(doc, 20, y, 190);
    y += 8;

    // ── 3. MAIN AMOUNT ──
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30);
    doc.text(isIncome ? 'AMOUNT RECEIVED' : 'AMOUNT PAID', 24, y);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(...(isIncome ? [34, 139, 34] : [200, 40, 40]));
    doc.text(`${isIncome ? '+' : '-'} ${this._currency(transaction.amount)}`, 186, y, { align: 'right' });

    y += 5;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120);
    doc.text(isIncome ? 'Income / Credit' : 'Expense / Debit', 24, y);
    y += 5;

    this._line(doc, y);
    y += 10;

    // ── 4. TRANSACTION DETAILS ──
    y = this._section(doc, y - 3, 'Transaction Details');

    y = this._row(doc, y, 'Description', transaction.title || 'Untitled');
    y = this._row(doc, y, 'Amount', this._currency(transaction.amount), { color: isIncome ? [34, 139, 34] : [200, 40, 40] });
    y = this._row(doc, y, 'Type', isIncome ? 'Income' : 'Expense');
    y = this._row(doc, y, 'Category', transaction.category || 'Uncategorized');
    y = this._row(doc, y, 'Date', Utils.formatDate(transaction.date));
    y = this._row(doc, y, 'Time', transaction.time ? Utils.formatTime(transaction.time) : '—');
    y = this._row(doc, y, 'Payment Method', transaction.paymentMethod || 'Not specified');

    if (transaction.isRecurring) {
      y = this._row(doc, y, 'Recurring', `Yes — ${transaction.recurringInterval || 'Monthly'}`);
    }

    if (transaction.tags && transaction.tags.length > 0) {
      y = this._row(doc, y, 'Tags', transaction.tags.join(', '));
    }

    // ── 5. NOTES ──
    if (transaction.notes && transaction.notes.trim()) {
      y += 2;
      y = this._section(doc, y, 'Notes');

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(70);
      const noteLines = doc.splitTextToSize(transaction.notes, 158);
      doc.text(noteLines.slice(0, 4), 24, y);
      y += Math.min(noteLines.length, 4) * 4.5 + 4;
    }

    // ── 6. MONTHLY CONTEXT (P&L + ALL Transactions) ──
    try {
      const txDate = new Date(transaction.date);
      const txMonth = txDate.getMonth() + 1;
      const txYear = txDate.getFullYear();
      const summary = await TransactionService.getMonthlySummary(txMonth, txYear);
      const spending = await TransactionService.getCategorySpending(txMonth, txYear);

      // --- P&L Overview ---
      y += 2;
      y = this._section(doc, y, `Monthly Summary — ${Utils.formatMonth(txMonth, txYear)}`);

      y = this._row(doc, y, 'Total Income', this._currency(summary.income), { color: [34, 139, 34] });
      y = this._row(doc, y, 'Total Expenses', this._currency(summary.expenses), { color: [200, 40, 40] });

      this._dashed(doc, 24, y - 2, 186);
      y += 3;

      const balance = summary.income - summary.expenses;
      y = this._row(doc, y, 'Net Balance (P&L)', this._currency(balance), {
        color: balance >= 0 ? [34, 139, 34] : [200, 40, 40],
        size: 10,
        gap: 8
      });

      y = this._row(doc, y, 'Total Transactions', `${summary.transactions.length}`, { bold: false });

      // --- Category Breakdown (ALL) ---
      const allCats = Object.entries(spending).sort((a, b) => b[1] - a[1]);
      if (allCats.length > 0) {
        y += 2;
        y = this._section(doc, y, 'Spending by Category');
        allCats.forEach(([cat, amt]) => {
          if (y > 268) { this._footer(doc); doc.addPage(); y = 20; }
          const pct = summary.expenses > 0 ? Math.round((amt / summary.expenses) * 100) : 0;
          y = this._row(doc, y, cat, `${this._currency(amt)}  (${pct}%)`, { size: 8.5, gap: 6, bold: false });
        });
      }

      // --- ALL Income Transactions ---
      const incomes = summary.transactions.filter(t => t.type === 'income').sort((a, b) => new Date(b.date) - new Date(a.date));
      if (incomes.length > 0) {
        y += 3;
        if (y > 240) { this._footer(doc); doc.addPage(); y = 20; }
        y = this._section(doc, y, 'All Income');

        // Header
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7);
        doc.setTextColor(100);
        doc.text('Date', 24, y);
        doc.text('Description', 55, y);
        doc.text('Category', 120, y);
        doc.text('Amount', 186, y, { align: 'right' });
        this._dashed(doc, 24, y + 2, 186);
        y += 6;

        incomes.forEach(tx => {
          if (y > 268) { this._footer(doc); doc.addPage(); y = 20; }
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(100);
          doc.text(Utils.formatDateShort(tx.date), 24, y);
          doc.setTextColor(50);
          doc.text((tx.title || '').substring(0, 30), 55, y);
          doc.setTextColor(100);
          doc.text((tx.category || '—').substring(0, 14), 120, y);
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(34, 139, 34);
          doc.text(`+${this._currency(tx.amount)}`, 186, y, { align: 'right' });
          y += 6;
        });

        // Income total
        this._dashed(doc, 120, y - 1, 186);
        y += 4;
        y = this._row(doc, y, 'Total Income', this._currency(summary.income), { color: [34, 139, 34], size: 9, gap: 7 });
      }

      // --- ALL Expense Transactions ---
      const expenses = summary.transactions.filter(t => t.type === 'expense').sort((a, b) => new Date(b.date) - new Date(a.date));
      if (expenses.length > 0) {
        y += 3;
        if (y > 240) { this._footer(doc); doc.addPage(); y = 20; }
        y = this._section(doc, y, 'All Expenses');

        // Header
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(7);
        doc.setTextColor(100);
        doc.text('Date', 24, y);
        doc.text('Description', 55, y);
        doc.text('Category', 120, y);
        doc.text('Amount', 186, y, { align: 'right' });
        this._dashed(doc, 24, y + 2, 186);
        y += 6;

        expenses.forEach(tx => {
          if (y > 268) { this._footer(doc); doc.addPage(); y = 20; }
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(8);
          doc.setTextColor(100);
          doc.text(Utils.formatDateShort(tx.date), 24, y);
          doc.setTextColor(50);
          doc.text((tx.title || '').substring(0, 30), 55, y);
          doc.setTextColor(100);
          doc.text((tx.category || '—').substring(0, 14), 120, y);
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(200, 40, 40);
          doc.text(`-${this._currency(tx.amount)}`, 186, y, { align: 'right' });
          y += 6;
        });

        // Expense total
        this._dashed(doc, 120, y - 1, 186);
        y += 4;
        y = this._row(doc, y, 'Total Expenses', this._currency(summary.expenses), { color: [200, 40, 40], size: 9, gap: 7 });
      }

    } catch (e) { console.warn('Monthly context failed:', e); }

    // ── 7. RECEIPT IMAGE ──
    if (transaction.receiptImage) {
      y += 2;
      y = this._section(doc, y, 'Attached Receipt');
      try {
        doc.setDrawColor(200);
        doc.setLineWidth(0.3);
        doc.rect(24, y, 70, 50);
        doc.addImage(transaction.receiptImage, 'JPEG', 25, y + 1, 68, 48);
        y += 55;
      } catch (e) {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(8);
        doc.setTextColor(150);
        doc.text('(Image could not be loaded)', 24, y + 4);
        y += 10;
      }
    }

    // ── 8. QR CODE ──
    try {
      const qrData = JSON.stringify({
        r: receiptNo,
        id: transaction.transactionId,
        a: transaction.amount,
        t: transaction.type,
        d: transaction.date
      });

      const qrDiv = document.createElement('div');
      qrDiv.style.cssText = 'position:fixed;top:-9999px;left:-9999px;';
      document.body.appendChild(qrDiv);
      new QRCode(qrDiv, { text: qrData, width: 120, height: 120, colorDark: '#333', colorLight: '#fff' });
      await new Promise(r => setTimeout(r, 300));

      const qrCanvas = qrDiv.querySelector('canvas');
      if (qrCanvas) {
        const qrY = Math.max(y + 4, 252);
        doc.addImage(qrCanvas.toDataURL(), 'PNG', 160, qrY, 22, 22);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(5.5);
        doc.setTextColor(150);
        doc.text('Scan to verify', 171, qrY + 25, { align: 'center' });
      }
      document.body.removeChild(qrDiv);
    } catch (e) { /* silent */ }

    // ── 9. FOOTER ──
    this._footer(doc);

    return doc;
  },


  // ═══════════════════════════════════════
  //  MONTHLY REPORT
  // ═══════════════════════════════════════
  async generateMonthlyReport(month, year) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const userName = localStorage.getItem('userName') || 'User';

    const summary = await TransactionService.getMonthlySummary(month, year);
    const spending = await TransactionService.getCategorySpending(month, year);

    // ── HEADER ──
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(30);
    doc.text('Monthly Financial Report', 24, 20);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(120);
    doc.text(`${Utils.formatMonth(month, year)}  •  ${userName}`, 24, 27);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('BudgetFlow', 186, 20, { align: 'right' });
    doc.setTextColor(150);
    doc.text('Personal Finance Tracker', 186, 26, { align: 'right' });

    this._line(doc, 31);
    let y = 42;

    // ── P&L SUMMARY ──
    y = this._section(doc, y - 3, 'Profit & Loss Summary');

    y = this._row(doc, y, 'Total Income', this._currency(summary.income), { color: [34, 139, 34], size: 10 });
    y = this._row(doc, y, 'Total Expenses', this._currency(summary.expenses), { color: [200, 40, 40], size: 10 });
    this._dashed(doc, 24, y - 2, 186);
    y += 3;

    const balance = summary.income - summary.expenses;
    y = this._row(doc, y, 'NET BALANCE', this._currency(balance), {
      color: balance >= 0 ? [34, 139, 34] : [200, 40, 40],
      size: 11,
      gap: 9
    });

    const incCount = summary.transactions.filter(t => t.type === 'income').length;
    const expCount = summary.transactions.filter(t => t.type === 'expense').length;
    y = this._row(doc, y, 'Total Transactions', `${summary.transactions.length}  (${incCount} income, ${expCount} expense)`, { bold: false, size: 8 });
    y += 4;

    // ── EXPENSE BREAKDOWN BY CATEGORY ──
    const sortedCats = Object.entries(spending).sort((a, b) => b[1] - a[1]);

    if (sortedCats.length > 0) {
      y = this._section(doc, y, 'Expense Breakdown by Category');

      // Table header
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100);
      doc.text('Category', 24, y);
      doc.text('Amount', 120, y);
      doc.text('Share', 155, y);
      this._dashed(doc, 24, y + 2, 186);
      y += 7;

      const totalExp = summary.expenses || 1;
      sortedCats.forEach(([cat, amt]) => {
        if (y > 266) { this._footer(doc); doc.addPage(); y = 20; }
        const pct = Math.round((amt / totalExp) * 100);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(50);
        doc.text(cat, 24, y);

        doc.setFont('helvetica', 'bold');
        doc.text(this._currency(amt), 120, y);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(120);
        doc.text(`${pct}%`, 155, y);
        y += 7;
      });
      y += 2;
    }

    // ── ALL EXPENSES ──
    const allExp = summary.transactions.filter(t => t.type === 'expense').sort((a, b) => new Date(b.date) - new Date(a.date));
    if (allExp.length > 0) {
      if (y > 230) { this._footer(doc); doc.addPage(); y = 20; }
      y = this._section(doc, y, 'All Expenses');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100);
      doc.text('#', 24, y);
      doc.text('Description', 32, y);
      doc.text('Category', 105, y);
      doc.text('Date', 140, y);
      doc.text('Amount', 186, y, { align: 'right' });
      this._dashed(doc, 24, y + 2, 186);
      y += 7;

      allExp.forEach((tx, i) => {
        if (y > 266) { this._footer(doc); doc.addPage(); y = 20; }
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(120);
        doc.text(`${i + 1}`, 24, y);

        doc.setTextColor(50);
        doc.text((tx.title || '').substring(0, 28), 32, y);

        doc.setTextColor(120);
        doc.setFontSize(8);
        doc.text((tx.category || '—').substring(0, 14), 105, y);
        doc.text(Utils.formatDateShort(tx.date), 140, y);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(200, 40, 40);
        doc.text(this._currency(tx.amount), 186, y, { align: 'right' });
        y += 7;
      });

      // Total
      this._dashed(doc, 120, y - 1, 186);
      y += 4;
      y = this._row(doc, y, 'Total Expenses', this._currency(summary.expenses), { color: [200, 40, 40], size: 9 });
      y += 2;
    }

    // ── ALL INCOME ──
    const allInc = summary.transactions.filter(t => t.type === 'income').sort((a, b) => new Date(b.date) - new Date(a.date));
    if (allInc.length > 0) {
      if (y > 230) { this._footer(doc); doc.addPage(); y = 20; }
      y = this._section(doc, y, 'All Income');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(100);
      doc.text('#', 24, y);
      doc.text('Description', 32, y);
      doc.text('Category', 105, y);
      doc.text('Date', 140, y);
      doc.text('Amount', 186, y, { align: 'right' });
      this._dashed(doc, 24, y + 2, 186);
      y += 7;

      allInc.forEach((tx, i) => {
        if (y > 266) { this._footer(doc); doc.addPage(); y = 20; }
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        doc.setTextColor(120);
        doc.text(`${i + 1}`, 24, y);

        doc.setTextColor(50);
        doc.text((tx.title || '').substring(0, 28), 32, y);

        doc.setTextColor(120);
        doc.setFontSize(8);
        doc.text((tx.category || '—').substring(0, 14), 105, y);
        doc.text(Utils.formatDateShort(tx.date), 140, y);

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(34, 139, 34);
        doc.text(this._currency(tx.amount), 186, y, { align: 'right' });
        y += 7;
      });

      // Total
      this._dashed(doc, 120, y - 1, 186);
      y += 4;
      y = this._row(doc, y, 'Total Income', this._currency(summary.income), { color: [34, 139, 34], size: 9 });
      y += 2;
    }

    // ── PAYMENT METHODS ──
    const methods = {};
    summary.transactions.filter(t => t.type === 'expense').forEach(t => {
      methods[t.paymentMethod || 'Other'] = (methods[t.paymentMethod || 'Other'] || 0) + t.amount;
    });
    const sortedMethods = Object.entries(methods).sort((a, b) => b[1] - a[1]);

    if (sortedMethods.length > 0) {
      if (y > 250) { this._footer(doc); doc.addPage(); y = 20; }
      y = this._section(doc, y, 'Payment Methods');
      sortedMethods.forEach(([method, amt]) => {
        if (y > 266) { this._footer(doc); doc.addPage(); y = 20; }
        const pct = summary.expenses > 0 ? Math.round((amt / summary.expenses) * 100) : 0;
        y = this._row(doc, y, method, `${this._currency(amt)}  (${pct}%)`, { bold: false, size: 8.5, gap: 6 });
      });
    }

    // ── FOOTER ──
    this._footer(doc);

    return doc;
  },


  downloadReceipt(doc, transaction) {
    doc.save(`Receipt_${transaction.transactionId || Date.now()}.pdf`);
  },

  downloadMonthlyReport(doc, month, year) {
    doc.save(`BudgetFlow_Report_${year}_${String(month).padStart(2, '0')}.pdf`);
  }
};

/* ============================================
   EXPORT SERVICE — CSV, Excel, JSON
   ============================================ */

const ExportService = {
  async exportCSV(transactions, filename = 'transactions.csv') {
    const headers = ['Date', 'Time', 'Title', 'Type', 'Amount', 'Category', 'Payment Method', 'Notes', 'Tags'];
    const rows = transactions.map(t => [
      t.date, t.time, `"${(t.title || '').replace(/"/g, '""')}"`,
      t.type, t.amount, t.category || '',
      t.paymentMethod || '', `"${(t.notes || '').replace(/"/g, '""')}"`,
      (t.tags || []).join('; ')
    ]);

    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    Utils.downloadFile(csv, filename, 'text/csv');
    Toast.success('CSV exported');
  },

  async exportExcel(transactions, filename = 'transactions.xlsx') {
    const data = transactions.map(t => ({
      Date: t.date, Time: t.time, Title: t.title,
      Type: t.type, Amount: t.amount,
      Category: t.category || '', 'Payment Method': t.paymentMethod || '',
      Notes: t.notes || '', Tags: (t.tags || []).join(', ')
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transactions');
    XLSX.writeFile(wb, filename);
    Toast.success('Excel exported');
  },

  async exportJSON(transactions, filename = 'transactions.json') {
    const json = JSON.stringify(transactions, null, 2);
    Utils.downloadFile(json, filename, 'application/json');
    Toast.success('JSON exported');
  }
};

/* ============================================
   BACKUP SERVICE — Import/Export
   ============================================ */

const BackupService = {
  async exportBackup() {
    try {
      const data = {
        version: 1,
        exportedAt: new Date().toISOString(),
        transactions: await db.transactions.toArray(),
        categories: await db.categories.toArray(),
        budgets: await db.budgets.toArray(),
        savingsGoals: await db.savingsGoals.toArray(),
        subscriptions: await db.subscriptions.toArray(),
        emis: await db.emis.toArray(),
        trash: await db.trash.toArray(),
        settings: {
          theme: localStorage.getItem('theme'),
          userName: localStorage.getItem('userName'),
          pinEnabled: localStorage.getItem('pinEnabled'),
          sessionTimeout: localStorage.getItem('sessionTimeout')
        }
      };

      const json = JSON.stringify(data, null, 2);
      const filename = `budgetflow_backup_${new Date().toISOString().split('T')[0]}.json`;
      Utils.downloadFile(json, filename);
      localStorage.setItem('lastBackupDate', new Date().toISOString());
      Toast.success('Backup exported successfully');
    } catch (err) {
      Toast.error('Backup export failed');
      console.error(err);
    }
  },

  async importBackup(file) {
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      if (!data.version || !data.transactions) {
        Toast.error('Invalid backup file format');
        return;
      }

      const confirmed = await Modal.confirm({
        title: 'Import Backup',
        message: 'This will replace ALL existing data. Are you sure?',
        confirmText: 'Import',
        confirmClass: 'btn-primary',
        icon: 'warning'
      });

      if (!confirmed) return;

      // Clear all tables
      await db.transactions.clear();
      await db.categories.clear();
      await db.budgets.clear();
      await db.savingsGoals.clear();
      await db.subscriptions.clear();
      await db.emis.clear();
      await db.trash.clear();

      // Import data
      if (data.transactions?.length) await db.transactions.bulkAdd(data.transactions);
      if (data.categories?.length) await db.categories.bulkAdd(data.categories);
      if (data.budgets?.length) await db.budgets.bulkAdd(data.budgets);
      if (data.savingsGoals?.length) await db.savingsGoals.bulkAdd(data.savingsGoals);
      if (data.subscriptions?.length) await db.subscriptions.bulkAdd(data.subscriptions);
      if (data.emis?.length) await db.emis.bulkAdd(data.emis);
      if (data.trash?.length) await db.trash.bulkAdd(data.trash);

      // Restore settings
      if (data.settings) {
        for (const [key, value] of Object.entries(data.settings)) {
          if (value != null) localStorage.setItem(key, value);
        }
      }

      Toast.success('Backup imported successfully');
      Router.currentRoute = null;
      Router.handleRoute();
      Sidebar.updateTrashBadge();
    } catch (err) {
      Toast.error('Backup import failed: ' + err.message);
      console.error(err);
    }
  }
};

/* ============================================
   SECURITY SERVICE — PIN Lock, Session
   ============================================ */

const SecurityService = {
  sessionTimer: null,

  isPinEnabled() {
    return localStorage.getItem('pinEnabled') === 'true';
  },

  async setupPin(pin) {
    const hash = await Utils.hashPin(pin);
    localStorage.setItem('pinHash', hash);
    localStorage.setItem('pinEnabled', 'true');
    Toast.success('PIN set up successfully');
  },

  async verifyPin(pin) {
    const hash = await Utils.hashPin(pin);
    return hash === localStorage.getItem('pinHash');
  },

  removePin() {
    localStorage.removeItem('pinHash');
    localStorage.setItem('pinEnabled', 'false');
    Toast.success('PIN removed');
  },

  showLockScreen() {
    const lock = document.getElementById('lock-screen');
    if (lock) {
      lock.classList.remove('hidden');
      lock.querySelector('.pin-digit')?.focus();
    }
  },

  hideLockScreen() {
    const lock = document.getElementById('lock-screen');
    if (lock) lock.classList.add('hidden');
  },

  initSessionTimeout() {
    const timeout = parseInt(localStorage.getItem('sessionTimeout')) || 0;
    if (timeout <= 0 || !this.isPinEnabled()) return;

    const reset = () => {
      clearTimeout(this.sessionTimer);
      this.sessionTimer = setTimeout(() => {
        this.showLockScreen();
      }, timeout * 60 * 1000);
    };

    ['click', 'keydown', 'mousemove', 'scroll'].forEach(event => {
      document.addEventListener(event, Utils.throttle(reset, 5000));
    });

    reset();
  },

  getStorageUsage() {
    let total = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      total += (localStorage.getItem(key) || '').length;
    }
    return {
      localStorage: total,
      localStorageFormatted: (total / 1024).toFixed(1) + ' KB'
    };
  }
};
