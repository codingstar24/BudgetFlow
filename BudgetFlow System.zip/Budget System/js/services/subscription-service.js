/* ============================================
   SUBSCRIPTION SERVICE — Subs & EMI Tracking
   ============================================ */

const SubscriptionService = {
  // Subscriptions
  async getAllSubs() {
    return db.subscriptions.toArray();
  },

  async addSub(data) {
    return db.subscriptions.add({
      ...data,
      amount: parseFloat(data.amount) || 0,
      isActive: true,
      createdAt: new Date().toISOString()
    });
  },

  async updateSub(id, data) {
    return db.subscriptions.update(id, data);
  },

  async deleteSub(id) {
    const confirmed = await Modal.confirm({
      title: 'Delete Subscription',
      message: 'Are you sure you want to delete this subscription?',
      confirmText: 'Delete',
      icon: 'danger'
    });
    if (confirmed) {
      await db.subscriptions.delete(id);
      Toast.success('Subscription deleted');
      return true;
    }
    return false;
  },

  // EMIs
  async getAllEmis() {
    return db.emis.toArray();
  },

  async addEmi(data) {
    return db.emis.add({
      ...data,
      totalAmount: parseFloat(data.totalAmount) || 0,
      emiAmount: parseFloat(data.emiAmount) || 0,
      paidAmount: parseFloat(data.paidAmount) || 0,
      totalInstallments: parseInt(data.totalInstallments) || 0,
      remainingInstallments: parseInt(data.remainingInstallments) || parseInt(data.totalInstallments) || 0,
      createdAt: new Date().toISOString()
    });
  },

  async updateEmi(id, data) {
    return db.emis.update(id, data);
  },

  async deleteEmi(id) {
    const confirmed = await Modal.confirm({
      title: 'Delete EMI',
      message: 'Are you sure you want to delete this EMI?',
      confirmText: 'Delete',
      icon: 'danger'
    });
    if (confirmed) {
      await db.emis.delete(id);
      Toast.success('EMI deleted');
      return true;
    }
    return false;
  },

  // Get upcoming payments
  async getUpcoming(days = 30) {
    const today = Utils.today();
    const limit = new Date();
    limit.setDate(limit.getDate() + days);
    const limitStr = limit.toISOString().split('T')[0];

    const subs = await this.getAllSubs();
    const emis = await this.getAllEmis();

    const upcoming = [];

    subs.filter(s => s.isActive && s.nextDueDate).forEach(s => {
      if (s.nextDueDate >= today && s.nextDueDate <= limitStr) {
        upcoming.push({ ...s, type: 'subscription', isOverdue: false });
      } else if (s.nextDueDate < today) {
        upcoming.push({ ...s, type: 'subscription', isOverdue: true });
      }
    });

    emis.forEach(e => {
      if (e.remainingInstallments > 0 && e.nextDueDate) {
        if (e.nextDueDate >= today && e.nextDueDate <= limitStr) {
          upcoming.push({ ...e, type: 'emi', isOverdue: false });
        } else if (e.nextDueDate < today) {
          upcoming.push({ ...e, type: 'emi', isOverdue: true });
        }
      }
    });

    return upcoming.sort((a, b) => {
      if (a.isOverdue && !b.isOverdue) return -1;
      if (!a.isOverdue && b.isOverdue) return 1;
      return (a.nextDueDate || '').localeCompare(b.nextDueDate || '');
    });
  },

  openSubModal(editData = null) {
    const isEdit = !!editData;
    const content = `
      <div class="form-group">
        <label class="form-label">Subscription Name <span class="required">*</span></label>
        <input type="text" class="form-input" id="sub-name" placeholder="e.g. Netflix" value="${Utils.escapeHtml(editData?.name || '')}">
      </div>
      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Amount <span class="required">*</span></label>
          <input type="number" class="form-input" id="sub-amount" placeholder="799" min="0" step="0.01" value="${editData?.amount || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">Billing Cycle</label>
          <select class="form-select" id="sub-cycle">
            <option value="monthly" ${editData?.billingCycle === 'monthly' ? 'selected' : ''}>Monthly</option>
            <option value="quarterly" ${editData?.billingCycle === 'quarterly' ? 'selected' : ''}>Quarterly</option>
            <option value="yearly" ${editData?.billingCycle === 'yearly' ? 'selected' : ''}>Yearly</option>
          </select>
        </div>
      </div>
      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Next Due Date</label>
          <input type="date" class="form-input" id="sub-due" value="${editData?.nextDueDate || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">Category</label>
          <input type="text" class="form-input" id="sub-category" placeholder="Entertainment" value="${Utils.escapeHtml(editData?.category || '')}">
        </div>
      </div>
    `;

    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="sub-save-btn">${isEdit ? 'Save Changes' : 'Add Subscription'}</button>
    `;

    const overlay = Modal.open({ title: isEdit ? 'Edit Subscription' : 'Add Subscription', content, footer });

    overlay.querySelector('#sub-save-btn')?.addEventListener('click', async () => {
      const name = overlay.querySelector('#sub-name').value.trim();
      const amount = overlay.querySelector('#sub-amount').value;
      if (!name || !amount) { Toast.warning('Please fill in name and amount'); return; }

      const data = {
        name,
        amount: parseFloat(amount),
        billingCycle: overlay.querySelector('#sub-cycle').value,
        nextDueDate: overlay.querySelector('#sub-due').value || '',
        category: overlay.querySelector('#sub-category').value.trim()
      };

      try {
        if (isEdit) {
          await this.updateSub(editData.id, data);
          Toast.success('Subscription updated');
        } else {
          await this.addSub(data);
          Toast.success('Subscription added');
        }
        Modal.close();
        Router.currentRoute = null;
        Router.handleRoute();
      } catch (err) { Toast.error('Failed to save'); }
    });
  },

  openEmiModal(editData = null) {
    const isEdit = !!editData;
    const content = `
      <div class="form-group">
        <label class="form-label">EMI Name <span class="required">*</span></label>
        <input type="text" class="form-input" id="emi-name" placeholder="e.g. Car Loan" value="${Utils.escapeHtml(editData?.name || '')}">
      </div>
      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Total Amount</label>
          <input type="number" class="form-input" id="emi-total" min="0" value="${editData?.totalAmount || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">EMI Amount <span class="required">*</span></label>
          <input type="number" class="form-input" id="emi-amount" min="0" value="${editData?.emiAmount || ''}">
        </div>
      </div>
      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Total Installments</label>
          <input type="number" class="form-input" id="emi-total-inst" min="1" value="${editData?.totalInstallments || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">Remaining Installments</label>
          <input type="number" class="form-input" id="emi-remaining" min="0" value="${editData?.remainingInstallments || ''}">
        </div>
      </div>
      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Paid Amount</label>
          <input type="number" class="form-input" id="emi-paid" min="0" value="${editData?.paidAmount || '0'}">
        </div>
        <div class="form-group">
          <label class="form-label">Next Due Date</label>
          <input type="date" class="form-input" id="emi-due" value="${editData?.nextDueDate || ''}">
        </div>
      </div>
      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Start Date</label>
        <input type="date" class="form-input" id="emi-start" value="${editData?.startDate || ''}">
      </div>
    `;

    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="emi-save-btn">${isEdit ? 'Save Changes' : 'Add EMI'}</button>
    `;

    const overlay = Modal.open({ title: isEdit ? 'Edit EMI' : 'Add EMI', content, footer });

    overlay.querySelector('#emi-save-btn')?.addEventListener('click', async () => {
      const name = overlay.querySelector('#emi-name').value.trim();
      const emiAmount = overlay.querySelector('#emi-amount').value;
      if (!name || !emiAmount) { Toast.warning('Please fill in name and EMI amount'); return; }

      const data = {
        name,
        totalAmount: parseFloat(overlay.querySelector('#emi-total').value) || 0,
        emiAmount: parseFloat(emiAmount),
        paidAmount: parseFloat(overlay.querySelector('#emi-paid').value) || 0,
        totalInstallments: parseInt(overlay.querySelector('#emi-total-inst').value) || 0,
        remainingInstallments: parseInt(overlay.querySelector('#emi-remaining').value) || 0,
        nextDueDate: overlay.querySelector('#emi-due').value || '',
        startDate: overlay.querySelector('#emi-start').value || ''
      };

      try {
        if (isEdit) {
          await this.updateEmi(editData.id, data);
          Toast.success('EMI updated');
        } else {
          await this.addEmi(data);
          Toast.success('EMI added');
        }
        Modal.close();
        Router.currentRoute = null;
        Router.handleRoute();
      } catch (err) { Toast.error('Failed to save'); }
    });
  }
};
