/* ============================================
   CATEGORY SERVICE — CRUD, Budget Limits
   ============================================ */

const CategoryService = {
  async getAll() {
    return db.categories.toArray();
  },

  async getByName(name) {
    return db.categories.where('name').equals(name).first();
  },

  async add(data) {
    return db.categories.add({
      ...data,
      isDefault: false,
      createdAt: new Date().toISOString()
    });
  },

  async update(id, data) {
    return db.categories.update(id, data);
  },

  async delete(id) {
    const cat = await db.categories.get(id);
    if (cat?.isDefault) {
      Toast.warning('Cannot delete default categories');
      return false;
    }
    // Check if any transactions use this category
    const txCount = await db.transactions.where('category').equals(cat.name).count();
    if (txCount > 0) {
      Toast.warning(`Cannot delete: ${txCount} transactions use this category`);
      return false;
    }

    const confirmed = await Modal.confirm({
      title: 'Delete Category',
      message: `Are you sure you want to delete "${cat.name}"?`,
      confirmText: 'Delete',
      icon: 'danger'
    });

    if (confirmed) {
      await db.categories.delete(id);
      Toast.success('Category deleted');
      return true;
    }
    return false;
  },

  // Open add/edit modal
  openModal(editData = null) {
    const isEdit = !!editData;
    const title = isEdit ? 'Edit Category' : 'Add Category';

    const iconOptions = ICON_OPTIONS.map(key => `
      <button type="button" class="icon-option ${editData?.icon === key ? 'selected' : ''}" data-icon="${key}">
        ${CATEGORY_ICONS[key]}
      </button>
    `).join('');

    const colorOptions = CATEGORY_COLORS.map(c => `
      <div class="color-swatch ${editData?.color === c ? 'selected' : ''}" data-color="${c}" style="background:${c}"></div>
    `).join('');

    const content = `
      <div class="form-group">
        <label class="form-label">Category Name <span class="required">*</span></label>
        <input type="text" class="form-input" id="cat-name" placeholder="e.g. Groceries" value="${Utils.escapeHtml(editData?.name || '')}">
      </div>

      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Icon</label>
        <div class="icon-grid" id="cat-icon-grid">
          ${iconOptions}
        </div>
        <input type="hidden" id="cat-icon" value="${editData?.icon || 'other'}">
      </div>

      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Color</label>
        <div class="color-grid" id="cat-color-grid">
          ${colorOptions}
        </div>
        <input type="hidden" id="cat-color" value="${editData?.color || '#4361ee'}">
      </div>

      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Monthly Budget Limit (optional)</label>
        <input type="number" class="form-input" id="cat-budget" placeholder="0.00" step="0.01" min="0" value="${editData?.budgetLimit || ''}">
      </div>
    `;

    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="cat-save-btn">${isEdit ? 'Save Changes' : 'Add Category'}</button>
    `;

    const overlay = Modal.open({ title, content, footer });

    // Icon selection
    overlay.querySelectorAll('.icon-option').forEach(btn => {
      btn.addEventListener('click', () => {
        overlay.querySelectorAll('.icon-option').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        overlay.querySelector('#cat-icon').value = btn.dataset.icon;
      });
    });

    // Color selection
    overlay.querySelectorAll('.color-swatch').forEach(swatch => {
      swatch.addEventListener('click', () => {
        overlay.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('selected'));
        swatch.classList.add('selected');
        overlay.querySelector('#cat-color').value = swatch.dataset.color;
      });
    });

    // Save
    overlay.querySelector('#cat-save-btn')?.addEventListener('click', async () => {
      const name = overlay.querySelector('#cat-name').value.trim();
      if (!name) {
        Toast.warning('Please enter a category name');
        return;
      }

      const data = {
        name,
        icon: overlay.querySelector('#cat-icon').value,
        color: overlay.querySelector('#cat-color').value,
        budgetLimit: parseFloat(overlay.querySelector('#cat-budget').value) || 0
      };

      try {
        if (isEdit) {
          await this.update(editData.id, data);
          Toast.success('Category updated');
        } else {
          // Check for duplicate names
          const existing = await this.getByName(name);
          if (existing) {
            Toast.warning('Category with this name already exists');
            return;
          }
          await this.add(data);
          Toast.success('Category added');
        }
        Modal.close();
        Router.currentRoute = null;
        Router.handleRoute();
      } catch (err) {
        Toast.error('Failed to save category');
        console.error(err);
      }
    });
  }
};
