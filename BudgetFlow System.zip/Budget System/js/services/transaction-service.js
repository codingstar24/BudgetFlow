/* ============================================
   TRANSACTION SERVICE — CRUD, Search, Filter
   ============================================ */

const TransactionService = {
  // Get all transactions for a month
  async getByMonth(month, year) {
    const start = Utils.getMonthStart(month, year);
    const end = Utils.getMonthEnd(month, year);
    return db.transactions
      .where('date').between(start, end, true, true)
      .reverse()
      .sortBy('date');
  },

  // Get all transactions
  async getAll(options = {}) {
    let collection = db.transactions.orderBy('date').reverse();

    const results = await collection.toArray();
    let filtered = results;

    // Apply filters
    if (options.type) filtered = filtered.filter(t => t.type === options.type);
    if (options.category) filtered = filtered.filter(t => t.category === options.category);
    if (options.paymentMethod) filtered = filtered.filter(t => t.paymentMethod === options.paymentMethod);
    if (options.startDate) filtered = filtered.filter(t => t.date >= options.startDate);
    if (options.endDate) filtered = filtered.filter(t => t.date <= options.endDate);
    if (options.search) {
      const q = options.search.toLowerCase();
      filtered = filtered.filter(t =>
        t.title?.toLowerCase().includes(q) ||
        t.notes?.toLowerCase().includes(q) ||
        t.tags?.some(tag => tag.toLowerCase().includes(q))
      );
    }

    // Sort
    if (options.sort === 'oldest') filtered.sort((a, b) => a.date.localeCompare(b.date));
    if (options.sort === 'highest') filtered.sort((a, b) => b.amount - a.amount);
    if (options.sort === 'lowest') filtered.sort((a, b) => a.amount - b.amount);

    return filtered;
  },

  // Get recent transactions
  async getRecent(limit = 5) {
    const all = await db.transactions.orderBy('createdAt').reverse().limit(limit).toArray();
    return all;
  },

  // Add transaction
  async add(data) {
    const transaction = {
      ...data,
      amount: parseFloat(data.amount) || 0,
      transactionId: Utils.generateTransactionId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    const id = await db.transactions.add(transaction);
    return { ...transaction, id };
  },

  // Update transaction
  async update(id, data) {
    await db.transactions.update(id, {
      ...data,
      amount: parseFloat(data.amount) || 0,
      updatedAt: new Date().toISOString()
    });
  },

  // Soft delete (move to trash)
  async softDelete(id) {
    const tx = await db.transactions.get(id);
    if (tx) {
      await db.trash.add({
        originalData: tx,
        type: 'transaction',
        deletedAt: new Date().toISOString()
      });
      await db.transactions.delete(id);
      Sidebar.updateTrashBadge();
    }
  },

  // Get monthly summary
  async getMonthlySummary(month, year) {
    const txs = await this.getByMonth(month, year);
    const income = txs.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const expenses = txs.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
    return { income, expenses, balance: income - expenses, transactions: txs };
  },

  // Get category spending for a month
  async getCategorySpending(month, year) {
    const txs = await this.getByMonth(month, year);
    const spending = {};
    txs.filter(t => t.type === 'expense').forEach(t => {
      spending[t.category] = (spending[t.category] || 0) + t.amount;
    });
    return spending;
  },

  // Get highest spending category
  async getHighestCategory(month, year) {
    const spending = await this.getCategorySpending(month, year);
    let max = 0, maxCat = '';
    for (const [cat, amt] of Object.entries(spending)) {
      if (amt > max) { max = amt; maxCat = cat; }
    }
    return { category: maxCat, amount: max };
  },

  // Open add/edit modal
  openAddModal(type = 'expense', editData = null) {
    const isEdit = !!editData;
    const title = isEdit ? 'Edit Transaction' : (type === 'income' ? 'Add Income' : 'Add Expense');

    // Build category options from DB
    db.categories.toArray().then(categories => {
      const catOptions = categories.map(c =>
        `<option value="${Utils.escapeHtml(c.name)}" ${editData?.category === c.name ? 'selected' : ''}>${Utils.escapeHtml(c.name)}</option>`
      ).join('');

      const methodOptions = PAYMENT_METHODS.map(m =>
        `<option value="${m}" ${editData?.paymentMethod === m ? 'selected' : ''}>${m}</option>`
      ).join('');

      const content = `
        <form id="tx-form">
          <input type="hidden" id="tx-type" value="${editData?.type || type}">
          ${isEdit ? `<input type="hidden" id="tx-edit-id" value="${editData.id}">` : ''}

          <div class="form-group">
            <label class="form-label">Title <span class="required">*</span></label>
            <input type="text" class="form-input" id="tx-title" placeholder="e.g. Grocery shopping" value="${Utils.escapeHtml(editData?.title || '')}" required>
          </div>

          <div class="form-row" style="margin-top:var(--space-4)">
            <div class="form-group">
              <label class="form-label">Amount <span class="required">*</span></label>
              <input type="number" class="form-input" id="tx-amount" placeholder="0.00" step="0.01" min="0" value="${editData?.amount || ''}" required>
            </div>
            <div class="form-group">
              <label class="form-label">Category</label>
              <select class="form-select" id="tx-category">
                <option value="">Select category</option>
                ${catOptions}
              </select>
            </div>
          </div>

          <div class="form-row" style="margin-top:var(--space-4)">
            <div class="form-group">
              <label class="form-label">Date</label>
              <input type="date" class="form-input" id="tx-date" value="${editData?.date || Utils.today()}">
            </div>
            <div class="form-group">
              <label class="form-label">Time</label>
              <input type="time" class="form-input" id="tx-time" value="${editData?.time || Utils.currentTime()}">
            </div>
          </div>

          <div class="form-group" style="margin-top:var(--space-4)">
            <label class="form-label">Payment Method</label>
            <select class="form-select" id="tx-method">
              <option value="">Select method</option>
              ${methodOptions}
            </select>
          </div>

          <div class="form-group" style="margin-top:var(--space-4)">
            <label class="form-label">Notes</label>
            <textarea class="form-textarea" id="tx-notes" placeholder="Add any notes..." rows="2">${Utils.escapeHtml(editData?.notes || '')}</textarea>
          </div>

          <div class="form-group" style="margin-top:var(--space-4)">
            <label class="form-label">Tags (comma separated)</label>
            <input type="text" class="form-input" id="tx-tags" placeholder="food, personal" value="${(editData?.tags || []).join(', ')}">
          </div>

          <div class="form-group" style="margin-top:var(--space-4)">
            <label class="form-label">Receipt Image</label>
            <div class="file-upload" id="tx-receipt-upload" onclick="document.getElementById('tx-receipt-file').click()">
              ${editData?.receiptImage
                ? `<img src="${editData.receiptImage}" class="file-upload-preview" id="tx-receipt-preview">`
                : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>`
              }
              <span class="file-upload-text">${editData?.receiptImage ? 'Change image' : 'Click to upload receipt'}</span>
            </div>
            <input type="file" id="tx-receipt-file" accept="image/*" class="hidden">
          </div>

          <div class="checkbox-wrapper" style="margin-top:var(--space-4)">
            <input type="checkbox" id="tx-recurring" ${editData?.isRecurring ? 'checked' : ''}>
            <label for="tx-recurring" class="form-label" style="margin:0;cursor:pointer">Mark as recurring</label>
          </div>

          <div id="tx-recurring-options" class="${editData?.isRecurring ? '' : 'hidden'}" style="margin-top:var(--space-3)">
            <div class="form-group">
              <label class="form-label">Repeat every</label>
              <select class="form-select" id="tx-recurring-interval">
                <option value="weekly" ${editData?.recurringInterval === 'weekly' ? 'selected' : ''}>Weekly</option>
                <option value="monthly" ${editData?.recurringInterval === 'monthly' ? 'selected' : ''}>Monthly</option>
                <option value="yearly" ${editData?.recurringInterval === 'yearly' ? 'selected' : ''}>Yearly</option>
              </select>
            </div>
          </div>
        </form>
      `;

      const footer = `
        <button class="btn btn-secondary" data-close-modal>Cancel</button>
        <button class="btn ${type === 'income' ? 'btn-success' : 'btn-primary'}" id="tx-save-btn">${isEdit ? 'Save Changes' : 'Add ' + (type === 'income' ? 'Income' : 'Expense')}</button>
      `;

      const overlay = Modal.open({ title, content, footer, size: 'lg' });

      // Receipt file upload
      overlay.querySelector('#tx-receipt-file')?.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (file) {
          const base64 = await Utils.fileToBase64(file);
          const upload = overlay.querySelector('#tx-receipt-upload');
          upload.innerHTML = `
            <img src="${base64}" class="file-upload-preview" id="tx-receipt-preview">
            <span class="file-upload-text">Change image</span>
          `;
          upload.dataset.image = base64;
        }
      });

      // Recurring toggle
      overlay.querySelector('#tx-recurring')?.addEventListener('change', (e) => {
        overlay.querySelector('#tx-recurring-options')?.classList.toggle('hidden', !e.target.checked);
      });

      // Save handler
      overlay.querySelector('#tx-save-btn')?.addEventListener('click', async () => {
        const titleVal = overlay.querySelector('#tx-title').value.trim();
        const amount = overlay.querySelector('#tx-amount').value;

        if (!titleVal || !amount) {
          Toast.warning('Please fill in title and amount');
          return;
        }

        const txData = {
          title: titleVal,
          amount: parseFloat(amount),
          type: overlay.querySelector('#tx-type').value,
          category: overlay.querySelector('#tx-category').value,
          date: overlay.querySelector('#tx-date').value || Utils.today(),
          time: overlay.querySelector('#tx-time').value || Utils.currentTime(),
          paymentMethod: overlay.querySelector('#tx-method').value,
          notes: overlay.querySelector('#tx-notes').value.trim(),
          tags: overlay.querySelector('#tx-tags').value.split(',').map(t => t.trim()).filter(Boolean),
          receiptImage: overlay.querySelector('#tx-receipt-upload')?.dataset?.image || editData?.receiptImage || '',
          isRecurring: overlay.querySelector('#tx-recurring').checked,
          recurringInterval: overlay.querySelector('#tx-recurring').checked
            ? overlay.querySelector('#tx-recurring-interval').value
            : null
        };

        try {
          if (isEdit) {
            await this.update(editData.id, txData);
            Toast.success('Transaction updated');
          } else {
            await this.add(txData);
            Toast.success(`${type === 'income' ? 'Income' : 'Expense'} added`);
          }
          Modal.close();

          // Refresh current page
          const currentRoute = Router.currentRoute;
          Router.currentRoute = null;
          Router.handleRoute();
        } catch (err) {
          Toast.error('Failed to save transaction');
          console.error(err);
        }
      });
    });
  }
};
