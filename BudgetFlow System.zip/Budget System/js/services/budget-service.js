/* ============================================
   BUDGET SERVICE — Monthly Budgets
   ============================================ */

const BudgetService = {
  async get(month, year) {
    return db.budgets.where({ month, year }).first();
  },

  async set(month, year, data) {
    const existing = await this.get(month, year);
    if (existing) {
      return db.budgets.update(existing.id, { ...data, updatedAt: new Date().toISOString() });
    } else {
      return db.budgets.add({
        month, year, ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  },

  async getOverview(month, year) {
    const budget = await this.get(month, year) || { totalBudget: 0, categoryBudgets: {} };
    const spending = await TransactionService.getCategorySpending(month, year);
    const categories = await CategoryService.getAll();

    const overview = categories.map(cat => {
      const limit = budget.categoryBudgets?.[cat.name] || cat.budgetLimit || 0;
      const spent = spending[cat.name] || 0;
      const percent = limit > 0 ? Utils.percentage(spent, limit) : 0;

      let status = 'on-track';
      if (percent >= 100) status = 'over';
      else if (percent >= 80) status = 'warning';

      return { ...cat, limit, spent, percent, status, remaining: Math.max(0, limit - spent) };
    }).filter(c => c.limit > 0 || c.spent > 0);

    const totalBudget = budget.totalBudget || 0;
    const totalSpent = Object.values(spending).reduce((a, b) => a + b, 0);

    return { budget, overview, totalBudget, totalSpent, categories };
  }
};

/* ============================================
   SAVINGS SERVICE — Goals CRUD
   ============================================ */

const SavingsService = {
  async getAll() {
    return db.savingsGoals.toArray();
  },

  async add(data) {
    return db.savingsGoals.add({
      ...data,
      savedAmount: parseFloat(data.savedAmount) || 0,
      targetAmount: parseFloat(data.targetAmount) || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });
  },

  async update(id, data) {
    return db.savingsGoals.update(id, {
      ...data,
      updatedAt: new Date().toISOString()
    });
  },

  async delete(id) {
    const confirmed = await Modal.confirm({
      title: 'Delete Savings Goal',
      message: 'Are you sure you want to delete this savings goal?',
      confirmText: 'Delete',
      icon: 'danger'
    });
    if (confirmed) {
      await db.savingsGoals.delete(id);
      Toast.success('Savings goal deleted');
      return true;
    }
    return false;
  },

  async addFunds(id, amount) {
    const goal = await db.savingsGoals.get(id);
    if (goal) {
      const newAmount = (goal.savedAmount || 0) + parseFloat(amount);
      await db.savingsGoals.update(id, {
        savedAmount: newAmount,
        updatedAt: new Date().toISOString()
      });

      if (newAmount >= goal.targetAmount) {
        Toast.success('🎉 Goal reached!', goal.name);
      } else {
        Toast.success(`Added ${Utils.formatCurrency(amount)}`, goal.name);
      }
    }
  },

  openModal(editData = null) {
    const isEdit = !!editData;
    const title = isEdit ? 'Edit Savings Goal' : 'New Savings Goal';

    const iconOptions = SAVINGS_ICON_OPTIONS.map(key => `
      <button type="button" class="icon-option ${editData?.icon === key ? 'selected' : ''}" data-icon="${key}">
        ${SAVINGS_ICONS[key]}
      </button>
    `).join('');

    const content = `
      <div class="form-group">
        <label class="form-label">Goal Name <span class="required">*</span></label>
        <input type="text" class="form-input" id="goal-name" placeholder="e.g. New Laptop" value="${Utils.escapeHtml(editData?.name || '')}">
      </div>

      <div class="form-row" style="margin-top:var(--space-4)">
        <div class="form-group">
          <label class="form-label">Target Amount <span class="required">*</span></label>
          <input type="number" class="form-input" id="goal-target" placeholder="50000" step="1" min="1" value="${editData?.targetAmount || ''}">
        </div>
        <div class="form-group">
          <label class="form-label">Already Saved</label>
          <input type="number" class="form-input" id="goal-saved" placeholder="0" step="1" min="0" value="${editData?.savedAmount || '0'}">
        </div>
      </div>

      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Deadline (optional)</label>
        <input type="date" class="form-input" id="goal-deadline" value="${editData?.deadline || ''}">
      </div>

      <div class="form-group" style="margin-top:var(--space-4)">
        <label class="form-label">Icon</label>
        <div class="icon-grid" id="goal-icon-grid">
          ${iconOptions}
        </div>
        <input type="hidden" id="goal-icon" value="${editData?.icon || 'piggybank'}">
      </div>
    `;

    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="goal-save-btn">${isEdit ? 'Save Changes' : 'Create Goal'}</button>
    `;

    const overlay = Modal.open({ title, content, footer });

    // Icon selection
    overlay.querySelectorAll('.icon-option').forEach(btn => {
      btn.addEventListener('click', () => {
        overlay.querySelectorAll('.icon-option').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        overlay.querySelector('#goal-icon').value = btn.dataset.icon;
      });
    });

    // Save
    overlay.querySelector('#goal-save-btn')?.addEventListener('click', async () => {
      const name = overlay.querySelector('#goal-name').value.trim();
      const target = overlay.querySelector('#goal-target').value;
      if (!name || !target) {
        Toast.warning('Please fill in name and target amount');
        return;
      }

      const data = {
        name,
        targetAmount: parseFloat(target),
        savedAmount: parseFloat(overlay.querySelector('#goal-saved').value) || 0,
        deadline: overlay.querySelector('#goal-deadline').value || null,
        icon: overlay.querySelector('#goal-icon').value
      };

      try {
        if (isEdit) {
          await this.update(editData.id, data);
          Toast.success('Goal updated');
        } else {
          await this.add(data);
          Toast.success('Goal created');
        }
        Modal.close();
        Router.currentRoute = null;
        Router.handleRoute();
      } catch (err) {
        Toast.error('Failed to save goal');
      }
    });
  }
};
