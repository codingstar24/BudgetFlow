/* ============================================
   ROUTER — Hash-based SPA Router
   ============================================ */

const Router = {
  routes: {},
  currentRoute: null,

  register(path, handler) {
    this.routes[path] = handler;
  },

  init() {
    window.addEventListener('hashchange', () => this.handleRoute());
    this.handleRoute();
  },

  navigate(path) {
    window.location.hash = path;
  },

  async handleRoute() {
    const hash = window.location.hash.slice(1) || 'dashboard';
    const route = hash.split('?')[0];

    if (this.currentRoute === route) return;
    this.currentRoute = route;

    // Update sidebar active state
    document.querySelectorAll('.sidebar-item').forEach(item => {
      item.classList.toggle('active', item.dataset.route === route);
    });

    // Update topbar title
    const titles = {
      dashboard: 'Dashboard',
      transactions: 'Transactions',
      categories: 'Categories',
      budget: 'Budget',
      savings: 'Savings Goals',
      subscriptions: 'Subscriptions & EMI',
      reports: 'Reports',
      trash: 'Trash',
      settings: 'Settings'
    };

    const topbarTitle = document.getElementById('topbar-title');
    if (topbarTitle) topbarTitle.textContent = titles[route] || 'Dashboard';

    // Execute route handler
    const content = document.getElementById('app-content');
    if (!content) return;

    // Fade out
    content.style.opacity = '0';
    content.style.transform = 'translateY(4px)';

    await new Promise(r => setTimeout(r, 150));

    if (this.routes[route]) {
      await this.routes[route](content);
    } else {
      this.routes['dashboard']?.(content);
    }

    // Fade in
    requestAnimationFrame(() => {
      content.style.opacity = '1';
      content.style.transform = 'translateY(0)';
    });

    // Close mobile sidebar
    document.querySelector('.sidebar')?.classList.remove('mobile-open');
    document.querySelector('.sidebar-overlay')?.classList.remove('visible');
  }
};
