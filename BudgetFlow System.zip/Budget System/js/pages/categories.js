/* ============================================
   CATEGORIES PAGE — Management
   ============================================ */

const CategoriesPage = {
  async render(container) {
    const categories = await CategoryService.getAll();
    const month = Utils.getCurrentMonth();
    const year = Utils.getCurrentYear();
    const spending = await TransactionService.getCategorySpending(month, year);

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Categories</h2>
          <p class="page-subtitle">Manage spending categories and budget limits</p>
        </div>
        <div class="page-header-right">
          <button class="btn btn-primary" onclick="CategoryService.openModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Category
          </button>
        </div>
      </div>

      <div class="category-grid stagger-children">
        ${categories.map(cat => {
          const spent = spending[cat.name] || 0;
          const limit = cat.budgetLimit || 0;
          const pct = limit > 0 ? Utils.percentage(spent, limit) : 0;
          const status = pct >= 100 ? 'danger' : pct >= 80 ? 'warning' : '';
          return `
            <div class="category-card">
              <div class="category-card-header">
                <div class="category-card-left">
                  <div class="category-card-icon" style="background:${Utils.colorWithAlpha(cat.color, 0.1)};color:${cat.color}">
                    ${Utils.getCategoryIcon(cat.icon)}
                  </div>
                  <div>
                    <div class="category-card-name">${Utils.escapeHtml(cat.name)}</div>
                    <div class="category-card-type">${cat.isDefault ? 'Default' : 'Custom'}</div>
                  </div>
                </div>
                <div class="dropdown">
                  <button class="btn btn-ghost btn-icon btn-sm" onclick="this.nextElementSibling.classList.toggle('active')">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
                  </button>
                  <div class="dropdown-menu">
                    <button class="dropdown-item" onclick="CategoryService.openModal(${JSON.stringify(cat).replace(/"/g, '&quot;')});this.closest('.dropdown-menu').classList.remove('active')">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      Edit
                    </button>
                    ${!cat.isDefault ? `
                      <button class="dropdown-item danger" onclick="CategoriesPage.deleteCategory(${cat.id});this.closest('.dropdown-menu').classList.remove('active')">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        Delete
                      </button>
                    ` : ''}
                  </div>
                </div>
              </div>

              ${limit > 0 ? `
                <div style="margin-top:var(--space-3)">
                  <div class="progress-info">
                    <span class="progress-label">Budget</span>
                    <span class="progress-value">${Utils.formatCurrencyShort(spent)} / ${Utils.formatCurrencyShort(limit)}</span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-bar-fill ${status}" style="width:${Math.min(pct, 100)}%"></div>
                  </div>
                </div>
              ` : ''}

              <div class="category-card-stats">
                <div class="category-stat">
                  <div class="category-stat-value">${Utils.formatCurrencyShort(spent)}</div>
                  <div class="category-stat-label">This Month</div>
                </div>
                <div class="category-stat">
                  <div class="category-stat-value">${limit > 0 ? Utils.formatCurrencyShort(limit) : '—'}</div>
                  <div class="category-stat-label">Limit</div>
                </div>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;

    // Close dropdowns on outside click
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.dropdown')) {
        document.querySelectorAll('.dropdown-menu.active').forEach(m => m.classList.remove('active'));
      }
    });
  },

  async deleteCategory(id) {
    const result = await CategoryService.delete(id);
    if (result) {
      Router.currentRoute = null;
      Router.handleRoute();
    }
  }
};

/* ============================================
   BUDGET PAGE — Monthly Budget Management
   ============================================ */

const BudgetPage = {
  currentMonth: Utils.getCurrentMonth(),
  currentYear: Utils.getCurrentYear(),

  async render(container) {
    const data = await BudgetService.getOverview(this.currentMonth, this.currentYear);
    const totalPct = data.totalBudget > 0 ? Utils.percentage(data.totalSpent, data.totalBudget) : 0;

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Budget</h2>
          <p class="page-subtitle">Plan and track your monthly spending</p>
        </div>
        <div class="page-header-right">
          <div class="budget-month-selector">
            <button class="budget-month-btn" onclick="BudgetPage.prevMonth()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <span class="budget-month-label">${Utils.formatMonth(this.currentMonth, this.currentYear)}</span>
            <button class="budget-month-btn" onclick="BudgetPage.nextMonth()">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
          </div>
          <button class="btn btn-primary" onclick="BudgetPage.openSetBudgetModal()">Set Budget</button>
        </div>
      </div>

      <!-- Overall Budget-->
      <div class="card" style="margin-bottom:var(--space-5)">
        <div class="card-header">
          <h3 class="card-title">Overall Budget</h3>
          <span class="budget-status ${totalPct >= 100 ? 'over' : totalPct >= 80 ? 'warning' : 'on-track'}">
            ${totalPct >= 100 ? 'Over Budget' : totalPct >= 80 ? 'Warning' : 'On Track'}
          </span>
        </div>
        ${data.totalBudget > 0 ? `
          <div class="progress-bar lg" style="margin-bottom:var(--space-3)">
            <div class="progress-bar-fill ${totalPct >= 100 ? 'danger' : totalPct >= 80 ? 'warning' : ''}" style="width:${Math.min(totalPct, 100)}%"></div>
          </div>
          <div class="budget-amounts">
            <div class="budget-amount-item">
              <div class="budget-amount-value">${Utils.formatCurrency(data.totalSpent)}</div>
              <div class="budget-amount-label">Spent</div>
            </div>
            <div class="budget-amount-item">
              <div class="budget-amount-value">${Utils.formatCurrency(data.totalBudget)}</div>
              <div class="budget-amount-label">Budget</div>
            </div>
            <div class="budget-amount-item">
              <div class="budget-amount-value" style="color:${data.totalBudget - data.totalSpent >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatCurrency(data.totalBudget - data.totalSpent)}</div>
              <div class="budget-amount-label">Remaining</div>
            </div>
          </div>
        ` : `<p style="color:var(--text-tertiary);text-align:center;padding:var(--space-4)">No budget set for this month. Click "Set Budget" to get started.</p>`}
      </div>

      <!-- Category Budgets -->
      <h3 style="font-size:var(--text-lg);font-weight:var(--weight-semibold);margin-bottom:var(--space-4)">Category Budgets</h3>
      <div class="budget-overview stagger-children">
        ${data.overview.length === 0 ? `
          <div class="card" style="grid-column:1/-1">
            <div class="empty-state" style="padding:var(--space-6)">
              <p class="empty-state-text">No category budgets set. Set budgets in Categories or click "Set Budget".</p>
            </div>
          </div>
        ` : data.overview.map(item => `
          <div class="budget-card">
            <div class="budget-card-header">
              <div class="budget-card-left">
                <span class="category-dot" style="background:${item.color};width:10px;height:10px"></span>
                <span style="font-weight:var(--weight-semibold)">${Utils.escapeHtml(item.name)}</span>
              </div>
              <span class="budget-status ${item.status}">${item.status === 'over' ? 'Over' : item.status === 'warning' ? 'Warning' : 'OK'}</span>
            </div>
            <div class="progress-bar" style="margin:var(--space-3) 0">
              <div class="progress-bar-fill ${item.status === 'over' ? 'danger' : item.status === 'warning' ? 'warning' : ''}" style="width:${Math.min(item.percent, 100)}%"></div>
            </div>
            <div class="budget-amounts">
              <div class="budget-amount-item"><div class="budget-amount-value">${Utils.formatCurrencyShort(item.spent)}</div><div class="budget-amount-label">Spent</div></div>
              <div class="budget-amount-item"><div class="budget-amount-value">${Utils.formatCurrencyShort(item.limit)}</div><div class="budget-amount-label">Limit</div></div>
              <div class="budget-amount-item"><div class="budget-amount-value" style="color:${item.remaining > 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatCurrencyShort(item.remaining)}</div><div class="budget-amount-label">Left</div></div>
            </div>
          </div>
        `).join('')}
      </div>

      <!-- Comparison Chart -->
      <div class="card" style="margin-top:var(--space-5)">
        <div class="card-header"><h3 class="card-title">Planned vs Actual</h3></div>
        <div class="chart-container" style="height:300px"><canvas id="budget-comparison-chart"></canvas></div>
      </div>
    `;

    // Render chart
    if (data.overview.length > 0) {
      const labels = data.overview.map(i => i.name);
      const planned = data.overview.map(i => i.limit);
      const actual = data.overview.map(i => i.spent);
      const theme = Charts.getThemeColors();

      Charts.bar('budget-comparison-chart', labels, [
        { label: 'Budget', data: planned, backgroundColor: Utils.colorWithAlpha(theme.accent, 0.3), borderColor: theme.accent, borderWidth: 1, borderRadius: 4 },
        { label: 'Spent', data: actual, backgroundColor: Utils.colorWithAlpha(theme.danger, 0.5), borderColor: theme.danger, borderWidth: 1, borderRadius: 4 }
      ]);
    }
  },

  prevMonth() {
    this.currentMonth--;
    if (this.currentMonth < 1) { this.currentMonth = 12; this.currentYear--; }
    Router.currentRoute = null;
    Router.handleRoute();
  },

  nextMonth() {
    this.currentMonth++;
    if (this.currentMonth > 12) { this.currentMonth = 1; this.currentYear++; }
    Router.currentRoute = null;
    Router.handleRoute();
  },

  async openSetBudgetModal() {
    const budget = await BudgetService.get(this.currentMonth, this.currentYear) || {};
    const categories = await CategoryService.getAll();

    const content = `
      <div class="form-group">
        <label class="form-label">Total Monthly Budget</label>
        <input type="number" class="form-input" id="budget-total" placeholder="50000" value="${budget.totalBudget || ''}">
      </div>
      <hr style="border:none;border-top:1px solid var(--border-light);margin:var(--space-4) 0">
      <h4 style="font-size:var(--text-md);margin-bottom:var(--space-3)">Category Budgets</h4>
      ${categories.map(cat => `
        <div class="form-group" style="margin-bottom:var(--space-3)">
          <label class="form-label" style="display:flex;align-items:center;gap:var(--space-2)">
            <span class="category-dot" style="background:${cat.color}"></span>
            ${Utils.escapeHtml(cat.name)}
          </label>
          <input type="number" class="form-input form-input-sm" data-cat="${cat.name}" placeholder="0" min="0" value="${budget.categoryBudgets?.[cat.name] || cat.budgetLimit || ''}">
        </div>
      `).join('')}
    `;

    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="budget-save-btn">Save Budget</button>
    `;

    const overlay = Modal.open({ title: `Budget — ${Utils.formatMonth(this.currentMonth, this.currentYear)}`, content, footer, size: 'lg' });

    overlay.querySelector('#budget-save-btn')?.addEventListener('click', async () => {
      const total = parseFloat(overlay.querySelector('#budget-total').value) || 0;
      const catBudgets = {};
      overlay.querySelectorAll('[data-cat]').forEach(input => {
        const val = parseFloat(input.value) || 0;
        if (val > 0) catBudgets[input.dataset.cat] = val;
      });

      await BudgetService.set(this.currentMonth, this.currentYear, {
        totalBudget: total,
        categoryBudgets: catBudgets
      });

      Toast.success('Budget saved');
      Modal.close();
      Router.currentRoute = null;
      Router.handleRoute();
    });
  }
};
