/* ============================================
   TRASH PAGE — Deleted Transactions
   ============================================ */

const TrashPage = {
  async render(container) {
    const trashItems = await db.trash.orderBy('deletedAt').reverse().toArray();

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Trash</h2>
          <p class="page-subtitle">${trashItems.length} deleted item${trashItems.length !== 1 ? 's' : ''}</p>
        </div>
        ${trashItems.length > 0 ? `
          <div class="page-header-right">
            <button class="btn btn-danger" id="empty-trash-btn">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
              Empty Trash
            </button>
          </div>
        ` : ''}
      </div>

      ${trashItems.length > 0 ? `
        <div class="trash-notice">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          Items in trash can be restored or permanently deleted.
        </div>
      ` : ''}

      ${trashItems.length === 0 ? `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          <h3 class="empty-state-title">Trash is empty</h3>
          <p class="empty-state-text">Deleted transactions will appear here.</p>
        </div>
      ` : `
        <div class="table-wrapper">
          <table class="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Amount</th>
                <th>Category</th>
                <th>Deleted</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${trashItems.map(item => {
                const tx = item.originalData;
                return `
                  <tr>
                    <td><span class="font-medium">${Utils.escapeHtml(tx?.title || 'Unknown')}</span></td>
                    <td><span class="amount ${tx?.type}">${tx?.type === 'income' ? '+' : '-'}${Utils.formatCurrency(tx?.amount || 0)}</span></td>
                    <td>${tx?.category || '—'}</td>
                    <td>${Utils.formatDateTime(item.deletedAt)}</td>
                    <td>
                      <div style="display:flex;gap:var(--space-1)">
                        <button class="btn btn-sm btn-outline" onclick="TrashPage.restore(${item.id})">Restore</button>
                        <button class="btn btn-sm btn-ghost" style="color:var(--danger)" onclick="TrashPage.permanentDelete(${item.id})">Delete</button>
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
      `}
    `;

    container.querySelector('#empty-trash-btn')?.addEventListener('click', async () => {
      const confirmed = await Modal.confirm({
        title: 'Empty Trash',
        message: 'This will permanently delete all items in trash. This cannot be undone.',
        confirmText: 'Empty Trash',
        icon: 'danger'
      });
      if (confirmed) {
        await db.trash.clear();
        Toast.success('Trash emptied');
        Sidebar.updateTrashBadge();
        Router.currentRoute = null;
        Router.handleRoute();
      }
    });
  },

  async restore(id) {
    const item = await db.trash.get(id);
    if (item && item.originalData) {
      const { id: oldId, ...data } = item.originalData;
      await db.transactions.add(data);
      await db.trash.delete(id);
      Toast.success('Transaction restored');
      Sidebar.updateTrashBadge();
      Router.currentRoute = null;
      Router.handleRoute();
    }
  },

  async permanentDelete(id) {
    const confirmed = await Modal.confirm({
      title: 'Permanent Delete',
      message: 'This transaction will be permanently deleted. This cannot be undone.',
      confirmText: 'Delete Forever',
      icon: 'danger'
    });
    if (confirmed) {
      await db.trash.delete(id);
      Toast.success('Permanently deleted');
      Sidebar.updateTrashBadge();
      Router.currentRoute = null;
      Router.handleRoute();
    }
  }
};

/* ============================================
   SETTINGS PAGE — Preferences, Security, Backup
   ============================================ */

const SettingsPage = {
  async render(container) {
    const userName = localStorage.getItem('userName') || '';
    const pinEnabled = SecurityService.isPinEnabled();
    const sessionTimeout = localStorage.getItem('sessionTimeout') || '0';
    const lastBackup = localStorage.getItem('lastBackupDate');
    const storage = SecurityService.getStorageUsage();
    const theme = Theme.get();

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Settings</h2>
          <p class="page-subtitle">Manage your preferences</p>
        </div>
      </div>

      <div class="settings-sections">
        <!-- Personal -->
        <div class="settings-section">
          <h3 class="settings-section-title">Personal</h3>
          <p class="settings-section-desc">Used for PDF receipts and reports</p>
          <div class="settings-row" style="border-bottom:none">
            <div class="settings-row-left">
              <div class="settings-row-label">Your Name</div>
              <div class="settings-row-desc">Displayed on receipts and reports</div>
            </div>
            <div class="settings-row-right" style="min-width:200px">
              <input type="text" class="form-input form-input-sm" id="setting-username" placeholder="Enter your name" value="${Utils.escapeHtml(userName)}">
            </div>
          </div>
        </div>

        <!-- Appearance -->
        <div class="settings-section">
          <h3 class="settings-section-title">Appearance</h3>
          <p class="settings-section-desc">Customize how BudgetFlow looks</p>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Dark Mode</div>
              <div class="settings-row-desc">Toggle between light and dark theme</div>
            </div>
            <div class="settings-row-right">
              <button class="toggle ${theme === 'dark' ? 'active' : ''}" id="setting-theme" onclick="Theme.toggle();this.classList.toggle('active')"></button>
            </div>
          </div>
        </div>

        <!-- Security -->
        <div class="settings-section">
          <h3 class="settings-section-title">Security</h3>
          <p class="settings-section-desc">Protect your financial data</p>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">PIN Lock</div>
              <div class="settings-row-desc">Require a PIN to access the app</div>
            </div>
            <div class="settings-row-right">
              <button class="toggle ${pinEnabled ? 'active' : ''}" id="setting-pin-toggle" onclick="SettingsPage.togglePin()"></button>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Session Timeout</div>
              <div class="settings-row-desc">Auto-lock after inactivity (requires PIN)</div>
            </div>
            <div class="settings-row-right" style="min-width:140px">
              <select class="form-select form-input-sm" id="setting-timeout" ${!pinEnabled ? 'disabled' : ''}>
                <option value="0" ${sessionTimeout === '0' ? 'selected' : ''}>Disabled</option>
                <option value="5" ${sessionTimeout === '5' ? 'selected' : ''}>5 minutes</option>
                <option value="15" ${sessionTimeout === '15' ? 'selected' : ''}>15 minutes</option>
                <option value="30" ${sessionTimeout === '30' ? 'selected' : ''}>30 minutes</option>
                <option value="60" ${sessionTimeout === '60' ? 'selected' : ''}>1 hour</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Data Management -->
        <div class="settings-section">
          <h3 class="settings-section-title">Data Management</h3>
          <p class="settings-section-desc">Backup, restore, and manage your data</p>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Export Backup</div>
              <div class="settings-row-desc">Download all data as a JSON file</div>
            </div>
            <div class="settings-row-right">
              <button class="btn btn-sm btn-secondary" onclick="BackupService.exportBackup()">Export</button>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Import Backup</div>
              <div class="settings-row-desc">Restore data from a backup file</div>
            </div>
            <div class="settings-row-right">
              <button class="btn btn-sm btn-secondary" onclick="document.getElementById('backup-file-input').click()">Import</button>
              <input type="file" id="backup-file-input" accept=".json" class="hidden">
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Last Backup</div>
              <div class="settings-row-desc">${lastBackup ? Utils.formatDateTime(lastBackup) : 'Never'}</div>
            </div>
          </div>
          <div class="settings-row">
            <div class="settings-row-left">
              <div class="settings-row-label">Storage Usage</div>
              <div class="settings-row-desc">localStorage: ${storage.localStorageFormatted}</div>
            </div>
          </div>
        </div>

        <!-- Danger Zone -->
        <div class="settings-section" style="border-color:var(--danger)">
          <h3 class="settings-section-title" style="color:var(--danger)">Danger Zone</h3>
          <p class="settings-section-desc">Irreversible actions</p>
          <div class="settings-row" style="border-bottom:none">
            <div class="settings-row-left">
              <div class="settings-row-label">Reset All Data</div>
              <div class="settings-row-desc">Delete all transactions, categories, and settings</div>
            </div>
            <div class="settings-row-right">
              <button class="btn btn-sm btn-danger" onclick="SettingsPage.resetAll()">Reset</button>
            </div>
          </div>
        </div>
      </div>
    `;

    // Name save
    container.querySelector('#setting-username')?.addEventListener('change', (e) => {
      localStorage.setItem('userName', e.target.value.trim());
      Toast.success('Name saved');
    });

    // Timeout save
    container.querySelector('#setting-timeout')?.addEventListener('change', (e) => {
      localStorage.setItem('sessionTimeout', e.target.value);
      SecurityService.initSessionTimeout();
      Toast.success('Timeout updated');
    });

    // Backup import
    container.querySelector('#backup-file-input')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) await BackupService.importBackup(file);
    });
  },

  async togglePin() {
    const btn = document.getElementById('setting-pin-toggle');
    if (SecurityService.isPinEnabled()) {
      SecurityService.removePin();
      btn?.classList.remove('active');
      document.getElementById('setting-timeout').disabled = true;
    } else {
      const content = `
        <div class="form-group">
          <label class="form-label">Set a 4-digit PIN</label>
          <div class="pin-input-group" style="justify-content:center;margin-top:var(--space-3)">
            <input type="password" class="pin-digit" maxlength="1" inputmode="numeric" pattern="[0-9]">
            <input type="password" class="pin-digit" maxlength="1" inputmode="numeric" pattern="[0-9]">
            <input type="password" class="pin-digit" maxlength="1" inputmode="numeric" pattern="[0-9]">
            <input type="password" class="pin-digit" maxlength="1" inputmode="numeric" pattern="[0-9]">
          </div>
        </div>
      `;
      const footer = `
        <button class="btn btn-secondary" data-close-modal>Cancel</button>
        <button class="btn btn-primary" id="pin-save-btn">Set PIN</button>
      `;

      const overlay = Modal.open({ title: 'Set PIN', content, footer });

      // Auto-focus and navigate between digits
      const digits = overlay.querySelectorAll('.pin-digit');
      digits[0]?.focus();
      digits.forEach((input, i) => {
        input.addEventListener('input', () => {
          if (input.value && i < 3) digits[i + 1]?.focus();
        });
        input.addEventListener('keydown', (e) => {
          if (e.key === 'Backspace' && !input.value && i > 0) digits[i - 1]?.focus();
        });
      });

      overlay.querySelector('#pin-save-btn')?.addEventListener('click', async () => {
        const pin = Array.from(digits).map(d => d.value).join('');
        if (pin.length !== 4) { Toast.warning('Please enter a 4-digit PIN'); return; }
        await SecurityService.setupPin(pin);
        btn?.classList.add('active');
        document.getElementById('setting-timeout').disabled = false;
        Modal.close();
      });
    }
  },

  async resetAll() {
    const confirmed = await Modal.confirm({
      title: 'Reset All Data',
      message: 'This will permanently delete ALL data including transactions, categories, budgets, goals, and settings. This CANNOT be undone. Consider exporting a backup first.',
      confirmText: 'Reset Everything',
      icon: 'danger'
    });
    if (confirmed) {
      await db.transactions.clear();
      await db.categories.clear();
      await db.budgets.clear();
      await db.savingsGoals.clear();
      await db.subscriptions.clear();
      await db.emis.clear();
      await db.trash.clear();
      await db.receipts.clear();
      localStorage.clear();
      await seedDefaults();
      Toast.success('All data has been reset');
      Router.currentRoute = null;
      Router.handleRoute();
      Sidebar.updateTrashBadge();
    }
  }
};
