/* ============================================
   TRANSACTIONS PAGE — List, Filter, CRUD
   ============================================ */

const TransactionsPage = {
  viewMode: 'table',
  filters: {},
  currentPage: 1,
  pageSize: 20,

  async render(container) {
    const categories = await CategoryService.getAll();
    const catMap = {};
    categories.forEach(c => catMap[c.name] = c);

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Transactions</h2>
          <p class="page-subtitle">Manage your income and expenses</p>
        </div>
        <div class="page-header-right">
          <div class="tx-search-bar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" class="form-input" id="tx-search" placeholder="Search transactions...">
          </div>
          <button class="btn btn-secondary" id="tx-filter-toggle">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
            Filters
          </button>
          <div class="view-toggle">
            <button class="view-toggle-btn ${this.viewMode === 'table' ? 'active' : ''}" data-view="table">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
            </button>
            <button class="view-toggle-btn ${this.viewMode === 'card' ? 'active' : ''}" data-view="card">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            </button>
          </div>
          <button class="btn btn-primary" onclick="TransactionService.openAddModal('expense')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add
          </button>
        </div>
      </div>

      <!-- Filter Panel -->
      <div class="filter-panel" id="tx-filter-panel">
        <div class="filter-panel-grid">
          <div class="form-group">
            <label class="form-label">Type</label>
            <select class="form-select form-input-sm" id="filter-type">
              <option value="">All</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Category</label>
            <select class="form-select form-input-sm" id="filter-category">
              <option value="">All</option>
              ${categories.map(c => `<option value="${c.name}">${c.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Start Date</label>
            <input type="date" class="form-input form-input-sm" id="filter-start">
          </div>
          <div class="form-group">
            <label class="form-label">End Date</label>
            <input type="date" class="form-input form-input-sm" id="filter-end">
          </div>
          <div class="form-group">
            <label class="form-label">Payment Method</label>
            <select class="form-select form-input-sm" id="filter-method">
              <option value="">All</option>
              ${PAYMENT_METHODS.map(m => `<option value="${m}">${m}</option>`).join('')}
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Sort By</label>
            <select class="form-select form-input-sm" id="filter-sort">
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="highest">Highest Amount</option>
              <option value="lowest">Lowest Amount</option>
            </select>
          </div>
        </div>
        <div class="filter-panel-actions">
          <button class="btn btn-ghost btn-sm" id="filter-clear">Clear Filters</button>
          <button class="btn btn-primary btn-sm" id="filter-apply">Apply</button>
        </div>
      </div>

      <!-- Transactions Container -->
      <div id="tx-container"></div>
    `;

    this.bindEvents(container, catMap);
    this.loadTransactions(catMap);
  },

  bindEvents(container, catMap) {
    // Filter toggle
    container.querySelector('#tx-filter-toggle')?.addEventListener('click', () => {
      container.querySelector('#tx-filter-panel')?.classList.toggle('active');
    });

    // View toggle
    container.querySelectorAll('.view-toggle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.viewMode = btn.dataset.view;
        container.querySelectorAll('.view-toggle-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.loadTransactions(catMap);
      });
    });

    // Search
    container.querySelector('#tx-search')?.addEventListener('input', Utils.debounce(() => {
      this.currentPage = 1;
      this.loadTransactions(catMap);
    }, 300));

    // Filter apply
    container.querySelector('#filter-apply')?.addEventListener('click', () => {
      this.currentPage = 1;
      this.loadTransactions(catMap);
    });

    // Filter clear
    container.querySelector('#filter-clear')?.addEventListener('click', () => {
      container.querySelectorAll('#tx-filter-panel select').forEach(s => s.value = '');
      container.querySelectorAll('#tx-filter-panel input').forEach(i => i.value = '');
      this.currentPage = 1;
      this.loadTransactions(catMap);
    });
  },

  async loadTransactions(catMap) {
    const txContainer = document.getElementById('tx-container');
    if (!txContainer) return;

    const options = {
      search: document.getElementById('tx-search')?.value || '',
      type: document.getElementById('filter-type')?.value || '',
      category: document.getElementById('filter-category')?.value || '',
      startDate: document.getElementById('filter-start')?.value || '',
      endDate: document.getElementById('filter-end')?.value || '',
      paymentMethod: document.getElementById('filter-method')?.value || '',
      sort: document.getElementById('filter-sort')?.value || 'newest'
    };

    const all = await TransactionService.getAll(options);
    const totalPages = Math.ceil(all.length / this.pageSize) || 1;
    const start = (this.currentPage - 1) * this.pageSize;
    const paginated = all.slice(start, start + this.pageSize);

    if (all.length === 0) {
      txContainer.innerHTML = `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
          <h3 class="empty-state-title">No transactions found</h3>
          <p class="empty-state-text">Add your first transaction to start tracking your finances.</p>
          <button class="btn btn-primary" onclick="TransactionService.openAddModal('expense')">Add Transaction</button>
        </div>
      `;
      return;
    }

    if (this.viewMode === 'table') {
      txContainer.innerHTML = `
        <div class="table-wrapper">
          <table class="data-table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Amount</th>
                <th>Category</th>
                <th>Date</th>
                <th>Method</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${paginated.map(tx => {
                const cat = catMap[tx.category];
                return `
                  <tr>
                    <td>
                      <div class="tx-table-title">${Utils.escapeHtml(tx.title)}</div>
                      ${tx.isRecurring ? '<span class="tx-recurring-badge">↻ Recurring</span>' : ''}
                    </td>
                    <td>
                      <span class="tx-table-amount amount ${tx.type}">${tx.type === 'income' ? '+' : '-'}${Utils.formatCurrency(tx.amount)}</span>
                    </td>
                    <td>
                      ${cat ? `<span class="category-badge" style="background:${Utils.colorWithAlpha(cat.color, 0.1)};color:${cat.color}"><span class="category-dot" style="background:${cat.color}"></span>${cat.name}</span>` : (tx.category || '—')}
                    </td>
                    <td>${Utils.formatDate(tx.date)}</td>
                    <td><span class="text-secondary">${tx.paymentMethod || '—'}</span></td>
                    <td>
                      <div class="tx-table-actions">
                        <button class="btn btn-ghost btn-icon btn-sm" data-tooltip="Edit" onclick="TransactionService.openAddModal('${tx.type}', ${JSON.stringify(tx).replace(/"/g, '&quot;')})">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                        </button>
                        <button class="btn btn-ghost btn-icon btn-sm" data-tooltip="Receipt" onclick="TransactionsPage.generateReceipt(${tx.id})">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                        </button>
                        <button class="btn btn-ghost btn-icon btn-sm" data-tooltip="Delete" onclick="TransactionsPage.deleteTransaction(${tx.id})">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--danger)"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
        ${this.renderPagination(totalPages)}
      `;
    } else {
      txContainer.innerHTML = `
        <div class="tx-cards-grid stagger-children">
          ${paginated.map(tx => {
            const cat = catMap[tx.category];
            const color = cat?.color || '#94a3b8';
            return `
              <div class="tx-card">
                <div class="tx-card-header">
                  <div class="tx-card-left">
                    <div class="tx-card-icon" style="background:${Utils.colorWithAlpha(color, 0.1)};color:${color}">
                      ${Utils.getCategoryIcon(cat?.icon || 'other')}
                    </div>
                    <div>
                      <div class="tx-card-title">${Utils.escapeHtml(tx.title)}</div>
                      <div class="tx-card-category">${tx.category || 'Uncategorized'}</div>
                    </div>
                  </div>
                  <div class="tx-card-amount amount ${tx.type}">${tx.type === 'income' ? '+' : '-'}${Utils.formatCurrency(tx.amount)}</div>
                </div>
                <div class="tx-card-details">
                  <div class="tx-card-detail">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    ${Utils.formatDate(tx.date)}
                  </div>
                  ${tx.paymentMethod ? `<div class="tx-card-detail">${tx.paymentMethod}</div>` : ''}
                  ${tx.isRecurring ? '<span class="tx-recurring-badge">↻ Recurring</span>' : ''}
                </div>
                <div class="tx-card-footer">
                  <div class="tx-card-tags">
                    ${(tx.tags || []).map(t => `<span class="tag">${Utils.escapeHtml(t)}</span>`).join('')}
                  </div>
                  <div class="tx-card-actions">
                    <button class="btn btn-ghost btn-icon btn-sm" data-tooltip="Edit" onclick="TransactionService.openAddModal('${tx.type}', ${JSON.stringify(tx).replace(/"/g, '&quot;')})">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    </button>
                    <button class="btn btn-ghost btn-icon btn-sm" data-tooltip="Delete" onclick="TransactionsPage.deleteTransaction(${tx.id})">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--danger)"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                    </button>
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
        ${this.renderPagination(totalPages)}
      `;
    }
  },

  renderPagination(totalPages) {
    if (totalPages <= 1) return '';
    let btns = '';
    btns += `<button class="pagination-btn" ${this.currentPage === 1 ? 'disabled' : ''} onclick="TransactionsPage.goToPage(${this.currentPage - 1})">‹</button>`;
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || Math.abs(i - this.currentPage) <= 2) {
        btns += `<button class="pagination-btn ${i === this.currentPage ? 'active' : ''}" onclick="TransactionsPage.goToPage(${i})">${i}</button>`;
      } else if (Math.abs(i - this.currentPage) === 3) {
        btns += `<span style="padding:0 4px;color:var(--text-muted)">...</span>`;
      }
    }
    btns += `<button class="pagination-btn" ${this.currentPage === totalPages ? 'disabled' : ''} onclick="TransactionsPage.goToPage(${this.currentPage + 1})">›</button>`;
    return `<div class="pagination">${btns}</div>`;
  },

  async goToPage(page) {
    this.currentPage = page;
    const catMap = {};
    (await CategoryService.getAll()).forEach(c => catMap[c.name] = c);
    this.loadTransactions(catMap);
  },

  async deleteTransaction(id) {
    const confirmed = await Modal.confirm({
      title: 'Delete Transaction',
      message: 'This will move the transaction to trash. You can restore it later.',
      confirmText: 'Delete',
      icon: 'danger'
    });
    if (confirmed) {
      await TransactionService.softDelete(id);
      Toast.success('Transaction moved to trash');
      const catMap = {};
      (await CategoryService.getAll()).forEach(c => catMap[c.name] = c);
      this.loadTransactions(catMap);
    }
  },

  async generateReceipt(id) {
    const tx = await db.transactions.get(id);
    if (tx) {
      try {
        const doc = await PDFService.generateReceipt(tx);
        PDFService.downloadReceipt(doc, tx);
        Toast.success('Receipt downloaded');
      } catch (err) {
        Toast.error('Failed to generate receipt');
        console.error(err);
      }
    }
  }
};
