/* ============================================
   DASHBOARD PAGE — Overview & Summary
   ============================================ */

const DashboardPage = {
  async render(container) {
    const month = Utils.getCurrentMonth();
    const year = Utils.getCurrentYear();

    // Show skeleton first
    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Dashboard</h2>
          <p class="page-subtitle">${Utils.formatMonth(month, year)}</p>
        </div>
      </div>
      <div class="summary-row">${Skeleton.summaryCards(5)}</div>
    `;

    // Fetch data
    const summary = await TransactionService.getMonthlySummary(month, year);
    const highest = await TransactionService.getHighestCategory(month, year);
    const recent = await TransactionService.getRecent(5);
    const upcoming = await SubscriptionService.getUpcoming(14);
    const goals = await SavingsService.getAll();
    const budgetData = await BudgetService.getOverview(month, year);
    const categories = await CategoryService.getAll();
    const catMap = {};
    categories.forEach(c => catMap[c.name] = c);

    const totalSaved = goals.reduce((s, g) => s + (g.savedAmount || 0), 0);
    const remaining = budgetData.totalBudget > 0
      ? budgetData.totalBudget - budgetData.totalSpent
      : summary.income - summary.expenses;

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Dashboard</h2>
          <p class="page-subtitle">${Utils.formatMonth(month, year)}</p>
        </div>
      </div>

      <!-- Summary Cards -->
      <div class="summary-row stagger-children">
        <div class="summary-card">
          <div class="summary-card-top">
            <div class="summary-card-icon" style="background:var(--accent-light);color:var(--accent)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
            </div>
          </div>
          <div class="summary-card-value">${Utils.formatCurrency(summary.balance)}</div>
          <div class="summary-card-label">Total Balance</div>
        </div>

        <div class="summary-card">
          <div class="summary-card-top">
            <div class="summary-card-icon" style="background:var(--success-light);color:var(--success)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
            </div>
          </div>
          <div class="summary-card-value" style="color:var(--success)">${Utils.formatCurrency(summary.income)}</div>
          <div class="summary-card-label">Monthly Income</div>
        </div>

        <div class="summary-card">
          <div class="summary-card-top">
            <div class="summary-card-icon" style="background:var(--danger-light);color:var(--danger)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>
            </div>
          </div>
          <div class="summary-card-value" style="color:var(--danger)">${Utils.formatCurrency(summary.expenses)}</div>
          <div class="summary-card-label">Monthly Expenses</div>
        </div>

        <div class="summary-card">
          <div class="summary-card-top">
            <div class="summary-card-icon" style="background:var(--info-light);color:var(--info)">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
          </div>
          <div class="summary-card-value">${Utils.formatCurrency(totalSaved)}</div>
          <div class="summary-card-label">Total Savings</div>
        </div>

        <div class="summary-card">
          <div class="summary-card-top">
            <div class="summary-card-icon" style="background:${remaining >= 0 ? 'var(--success-light)' : 'var(--danger-light)'};color:${remaining >= 0 ? 'var(--success)' : 'var(--danger)'}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
            </div>
          </div>
          <div class="summary-card-value" style="color:${remaining >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatCurrency(remaining)}</div>
          <div class="summary-card-label">Remaining Budget</div>
        </div>
      </div>

      <!-- Quick Actions -->
      <div class="quick-actions">
        <button class="quick-action-btn income" onclick="TransactionService.openAddModal('income')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Income
        </button>
        <button class="quick-action-btn expense" onclick="TransactionService.openAddModal('expense')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Expense
        </button>
      </div>

      <!-- Charts and Lists Row -->
      <div class="dashboard-grid-3">
        <!-- Income vs Expenses Chart -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Income vs Expenses</h3>
            ${highest.category ? `<span class="badge badge-warning">Top: ${highest.category}</span>` : ''}
          </div>
          <div class="chart-container" style="height:260px">
            <canvas id="dashboard-bar-chart"></canvas>
          </div>
        </div>

        <!-- Spending by Category Chart -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Spending by Category</h3>
          </div>
          <div class="chart-container" style="height:260px">
            <canvas id="dashboard-doughnut-chart"></canvas>
          </div>
        </div>
      </div>

      <div class="dashboard-grid-2">
        <!-- Recent Transactions -->
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Recent Transactions</h3>
            <a href="#transactions" style="font-size:var(--text-sm);font-weight:var(--weight-medium)">View All</a>
          </div>
          <div class="card-body" id="recent-transactions-list">
            ${recent.length === 0 ? `
              <div class="empty-state" style="padding:var(--space-6) 0">
                <div class="empty-state-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                </div>
                <p class="empty-state-text">No transactions yet. Add your first one!</p>
              </div>
            ` : recent.map(tx => {
              const cat = catMap[tx.category];
              const color = cat?.color || '#94a3b8';
              return `
                <div class="recent-tx-item">
                  <div class="recent-tx-icon" style="background:${Utils.colorWithAlpha(color, 0.1)};color:${color}">
                    ${Utils.getCategoryIcon(cat?.icon || 'other')}
                  </div>
                  <div class="recent-tx-info">
                    <div class="recent-tx-title">${Utils.escapeHtml(tx.title)}</div>
                    <div class="recent-tx-category">${tx.category || 'Uncategorized'} • ${Utils.formatDateShort(tx.date)}</div>
                  </div>
                  <div class="recent-tx-amount ${tx.type}">${tx.type === 'income' ? '+' : '-'}${Utils.formatCurrency(tx.amount)}</div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Upcoming Bills + Budget Overview -->
        <div style="display:flex;flex-direction:column;gap:var(--space-5)">
          <!-- Upcoming Bills -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Upcoming Bills</h3>
              <a href="#subscriptions" style="font-size:var(--text-sm);font-weight:var(--weight-medium)">Manage</a>
            </div>
            <div class="card-body">
              ${upcoming.length === 0 ? `
                <p style="font-size:var(--text-sm);color:var(--text-tertiary);text-align:center;padding:var(--space-4)">No upcoming bills</p>
              ` : upcoming.slice(0, 4).map(item => `
                <div class="upcoming-bill-item">
                  <div class="upcoming-bill-icon" style="background:${item.isOverdue ? 'var(--danger-light)' : 'var(--accent-light)'};color:${item.isOverdue ? 'var(--danger)' : 'var(--accent)'}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                  </div>
                  <div class="upcoming-bill-info">
                    <div class="upcoming-bill-name">${Utils.escapeHtml(item.name)}</div>
                    <div class="upcoming-bill-date">${item.isOverdue ? '<span style="color:var(--danger)">Overdue</span>' : Utils.formatDateShort(item.nextDueDate)}</div>
                  </div>
                  <div class="upcoming-bill-amount">${Utils.formatCurrency(item.amount || item.emiAmount)}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Budget Overview Mini -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Budget Overview</h3>
              <a href="#budget" style="font-size:var(--text-sm);font-weight:var(--weight-medium)">Details</a>
            </div>
            <div class="card-body">
              ${budgetData.overview.length === 0 ? `
                <p style="font-size:var(--text-sm);color:var(--text-tertiary);text-align:center;padding:var(--space-4)">No budgets set yet</p>
              ` : budgetData.overview.slice(0, 4).map(item => `
                <div class="budget-mini-item">
                  <div class="budget-mini-header">
                    <div class="budget-mini-label">
                      <span class="category-dot" style="background:${item.color}"></span>
                      ${Utils.escapeHtml(item.name)}
                    </div>
                    <div class="budget-mini-value">${Utils.formatCurrencyShort(item.spent)} / ${Utils.formatCurrencyShort(item.limit)}</div>
                  </div>
                  <div class="progress-bar">
                    <div class="progress-bar-fill ${item.status === 'over' ? 'danger' : item.status === 'warning' ? 'warning' : ''}"
                      style="width:${Math.min(item.percent, 100)}%"></div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>

      <!-- Savings Goals Mini -->
      ${goals.length > 0 ? `
        <div class="card" style="margin-top:var(--space-5)">
          <div class="card-header">
            <h3 class="card-title">Savings Progress</h3>
            <a href="#savings" style="font-size:var(--text-sm);font-weight:var(--weight-medium)">View All</a>
          </div>
          <div class="savings-mini-grid">
            ${goals.slice(0, 4).map(goal => {
              const pct = Utils.percentage(goal.savedAmount, goal.targetAmount);
              return `
                <div class="savings-mini-card">
                  ${Charts.progressCircle(pct, 64, 5)}
                  <div class="savings-mini-name">${Utils.escapeHtml(goal.name)}</div>
                  <div class="savings-mini-amount">${Utils.formatCurrencyShort(goal.savedAmount)} / ${Utils.formatCurrencyShort(goal.targetAmount)}</div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      ` : ''}
    `;

    // Render charts
    this.renderCharts(summary, categories, catMap, month, year);
  },

  async renderCharts(summary, categories, catMap, month, year) {
    const spending = await TransactionService.getCategorySpending(month, year);

    // Bar chart — Income vs Expenses
    const theme = Charts.getThemeColors();
    Charts.bar('dashboard-bar-chart',
      ['Income', 'Expenses'],
      [{
        label: 'Amount',
        data: [summary.income, summary.expenses],
        backgroundColor: [Utils.colorWithAlpha(theme.success, 0.7), Utils.colorWithAlpha(theme.danger, 0.7)],
        borderColor: [theme.success, theme.danger],
        borderWidth: 1,
        borderRadius: 6
      }]
    );

    // Doughnut chart — Category spending
    const catLabels = [];
    const catData = [];
    const catColors = [];

    Object.entries(spending).sort((a, b) => b[1] - a[1]).forEach(([name, amount]) => {
      catLabels.push(name);
      catData.push(amount);
      catColors.push(catMap[name]?.color || '#94a3b8');
    });

    if (catLabels.length > 0) {
      Charts.doughnut('dashboard-doughnut-chart', catLabels, catData, catColors);
    } else {
      const canvas = document.getElementById('dashboard-doughnut-chart');
      if (canvas) {
        canvas.parentElement.innerHTML = `
          <div class="empty-state" style="padding:var(--space-6) 0">
            <p class="empty-state-text">No expense data yet</p>
          </div>
        `;
      }
    }
  }
};
