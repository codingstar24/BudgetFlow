/* ============================================
   REPORTS PAGE — Charts & Export
   ============================================ */

const ReportsPage = {
  period: 'monthly',
  startDate: '',
  endDate: '',

  async render(container) {
    const range = ReportService.getDateRange(this.period);
    if (!this.startDate) this.startDate = range.startDate;
    if (!this.endDate) this.endDate = range.endDate;

    const report = await ReportService.getReport(this.startDate, this.endDate);
    const categories = await CategoryService.getAll();
    const catMap = {};
    categories.forEach(c => catMap[c.name] = c);

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Reports</h2>
          <p class="page-subtitle">Analyze your financial data</p>
        </div>
      </div>

      <div class="report-controls">
        <div style="display:flex;gap:var(--space-2);flex-wrap:wrap">
          ${['daily', 'weekly', 'monthly', 'yearly'].map(p => `
            <button class="filter-chip ${this.period === p ? 'active' : ''}" onclick="ReportsPage.setPeriod('${p}')">${p.charAt(0).toUpperCase() + p.slice(1)}</button>
          `).join('')}
        </div>
        <div class="report-date-range">
          <input type="date" class="form-input form-input-sm" id="report-start" value="${this.startDate}" style="width:140px">
          <span style="color:var(--text-muted)">to</span>
          <input type="date" class="form-input form-input-sm" id="report-end" value="${this.endDate}" style="width:140px">
          <button class="btn btn-sm btn-secondary" id="report-apply">Apply</button>
        </div>
        <div class="report-export-btns">
          <button class="btn btn-sm btn-secondary" onclick="ReportsPage.exportPDF()">PDF</button>
          <button class="btn btn-sm btn-secondary" onclick="ReportsPage.exportExcel()">Excel</button>
          <button class="btn btn-sm btn-secondary" onclick="ReportsPage.exportCSV()">CSV</button>
          <button class="btn btn-sm btn-secondary" onclick="ReportsPage.exportJSON()">JSON</button>
        </div>
      </div>

      <!-- Summary Stats-->
      <div class="report-summary-grid stagger-children">
        <div class="summary-card">
          <div class="summary-card-label">Total Income</div>
          <div class="summary-card-value" style="color:var(--success)">${Utils.formatCurrency(report.income)}</div>
        </div>
        <div class="summary-card">
          <div class="summary-card-label">Total Expenses</div>
          <div class="summary-card-value" style="color:var(--danger)">${Utils.formatCurrency(report.expenses)}</div>
        </div>
        <div class="summary-card">
          <div class="summary-card-label">Net Balance</div>
          <div class="summary-card-value" style="color:${report.balance >= 0 ? 'var(--success)' : 'var(--danger)'}">${Utils.formatCurrency(report.balance)}</div>
        </div>
        <div class="summary-card">
          <div class="summary-card-label">Transactions</div>
          <div class="summary-card-value">${report.transactionCount}</div>
        </div>
      </div>

      <!-- Charts -->
      <div class="report-charts-grid">
        <div class="report-chart-card">
          <div class="report-chart-title">Income vs Expenses Trend</div>
          <div class="chart-container" style="height:280px"><canvas id="report-trend-chart"></canvas></div>
        </div>
        <div class="report-chart-card">
          <div class="report-chart-title">Spending by Category</div>
          <div class="chart-container" style="height:280px"><canvas id="report-category-chart"></canvas></div>
        </div>
      </div>

      <div class="report-charts-grid">
        <div class="report-chart-card">
          <div class="report-chart-title">Monthly Comparison</div>
          <div class="chart-container" style="height:280px"><canvas id="report-monthly-chart"></canvas></div>
        </div>
        <div class="report-chart-card">
          <div class="report-chart-title">Payment Methods</div>
          <div class="chart-container" style="height:280px"><canvas id="report-method-chart"></canvas></div>
        </div>
      </div>

      <!-- Savings Growth -->
      <div class="card" style="margin-top:var(--space-5)">
        <div class="card-header"><h3 class="card-title">Savings Progress</h3></div>
        <div class="chart-container" style="height:250px"><canvas id="report-savings-chart"></canvas></div>
      </div>
    `;

    // Apply button
    container.querySelector('#report-apply')?.addEventListener('click', () => {
      this.startDate = document.getElementById('report-start')?.value || this.startDate;
      this.endDate = document.getElementById('report-end')?.value || this.endDate;
      this.period = 'custom';
      Router.currentRoute = null;
      Router.handleRoute();
    });

    this.renderCharts(report, catMap);
  },

  async renderCharts(report, catMap) {
    const theme = Charts.getThemeColors();

    // Trend chart (monthly data)
    const monthKeys = Object.keys(report.monthly).sort();
    if (monthKeys.length > 0) {
      Charts.line('report-trend-chart',
        monthKeys.map(k => { const [y, m] = k.split('-'); return Utils.formatMonth(parseInt(m), parseInt(y)); }),
        [
          { label: 'Income', data: monthKeys.map(k => report.monthly[k].income), borderColor: theme.success, backgroundColor: Utils.colorWithAlpha(theme.success, 0.1), fill: true, tension: 0.3, pointRadius: 3 },
          { label: 'Expenses', data: monthKeys.map(k => report.monthly[k].expense), borderColor: theme.danger, backgroundColor: Utils.colorWithAlpha(theme.danger, 0.1), fill: true, tension: 0.3, pointRadius: 3 }
        ]
      );
    }

    // Category doughnut
    const catEntries = Object.entries(report.categorySpending).sort((a, b) => b[1] - a[1]);
    if (catEntries.length > 0) {
      Charts.doughnut('report-category-chart',
        catEntries.map(([name]) => name),
        catEntries.map(([, amt]) => amt),
        catEntries.map(([name]) => catMap[name]?.color || '#94a3b8')
      );
    }

    // Monthly comparison bar
    if (monthKeys.length > 0) {
      Charts.bar('report-monthly-chart',
        monthKeys.map(k => { const [y, m] = k.split('-'); return Utils.formatMonth(parseInt(m), parseInt(y)); }),
        [
          { label: 'Income', data: monthKeys.map(k => report.monthly[k].income), backgroundColor: Utils.colorWithAlpha(theme.success, 0.6), borderRadius: 4 },
          { label: 'Expenses', data: monthKeys.map(k => report.monthly[k].expense), backgroundColor: Utils.colorWithAlpha(theme.danger, 0.6), borderRadius: 4 }
        ]
      );
    }

    // Payment methods doughnut
    const methodEntries = Object.entries(report.paymentMethods);
    if (methodEntries.length > 0) {
      const methodColors = ['#4361ee', '#7c3aed', '#ec4899', '#f97316', '#eab308', '#22c55e', '#06b6d4'];
      Charts.doughnut('report-method-chart',
        methodEntries.map(([name]) => name),
        methodEntries.map(([, amt]) => amt),
        methodEntries.map((_, i) => methodColors[i % methodColors.length])
      );
    }

    // Savings progress
    const savingsData = await ReportService.getSavingsHistory();
    if (savingsData.length > 0) {
      Charts.bar('report-savings-chart',
        savingsData.map(s => s.name),
        [
          { label: 'Saved', data: savingsData.map(s => s.saved), backgroundColor: Utils.colorWithAlpha(theme.success, 0.6), borderRadius: 4 },
          { label: 'Target', data: savingsData.map(s => s.target), backgroundColor: Utils.colorWithAlpha(theme.accent, 0.2), borderRadius: 4 }
        ]
      );
    }
  },

  setPeriod(period) {
    this.period = period;
    const range = ReportService.getDateRange(period);
    this.startDate = range.startDate;
    this.endDate = range.endDate;
    Router.currentRoute = null;
    Router.handleRoute();
  },

  async getTransactions() {
    return TransactionService.getAll({
      startDate: this.startDate,
      endDate: this.endDate
    });
  },

  async exportPDF() {
    try {
      const month = Utils.getCurrentMonth();
      const year = Utils.getCurrentYear();
      const doc = await PDFService.generateMonthlyReport(month, year);
      PDFService.downloadMonthlyReport(doc, month, year);
      Toast.success('PDF report downloaded');
    } catch (err) { Toast.error('PDF export failed'); console.error(err); }
  },

  async exportExcel() {
    const txs = await this.getTransactions();
    ExportService.exportExcel(txs, `report_${this.startDate}_${this.endDate}.xlsx`);
  },

  async exportCSV() {
    const txs = await this.getTransactions();
    ExportService.exportCSV(txs, `report_${this.startDate}_${this.endDate}.csv`);
  },

  async exportJSON() {
    const txs = await this.getTransactions();
    ExportService.exportJSON(txs, `report_${this.startDate}_${this.endDate}.json`);
  }
};
