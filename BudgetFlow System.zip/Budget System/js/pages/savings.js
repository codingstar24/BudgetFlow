/* ============================================
   SAVINGS PAGE — Goals & Progress
   ============================================ */

const SavingsPage = {
  async render(container) {
    const goals = await SavingsService.getAll();

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Savings Goals</h2>
          <p class="page-subtitle">Track your savings progress</p>
        </div>
        <div class="page-header-right">
          <button class="btn btn-primary" onclick="SavingsService.openModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            New Goal
          </button>
        </div>
      </div>

      ${goals.length === 0 ? `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8"/><line x1="12" y1="6" x2="12" y2="8"/><line x1="12" y1="16" x2="12" y2="18"/></svg>
          <h3 class="empty-state-title">No savings goals yet</h3>
          <p class="empty-state-text">Create your first savings goal to start tracking progress.</p>
          <button class="btn btn-primary" onclick="SavingsService.openModal()">Create Goal</button>
        </div>
      ` : `
        <div class="savings-grid stagger-children">
          ${goals.map(goal => {
            const pct = Utils.percentage(goal.savedAmount, goal.targetAmount);
            const daysLeft = goal.deadline ? Utils.daysUntil(goal.deadline) : null;
            const color = pct >= 100 ? 'var(--success)' : 'var(--accent)';
            return `
              <div class="savings-card">
                <div class="savings-card-icon" style="background:${pct >= 100 ? 'var(--success-light)' : 'var(--accent-light)'};color:${color}">
                  ${Utils.getSavingsIcon(goal.icon)}
                </div>
                <div class="savings-card-name">${Utils.escapeHtml(goal.name)}</div>
                <div class="savings-card-deadline">
                  ${goal.deadline
                    ? (daysLeft >= 0 ? `${daysLeft} days left` : '<span style="color:var(--danger)">Past deadline</span>')
                    : 'No deadline'
                  }
                </div>

                ${Charts.progressCircle(pct, 100, 7, color)}

                <div class="savings-card-amounts">
                  <div class="savings-amount-item">
                    <div class="savings-amount-value">${Utils.formatCurrencyShort(goal.savedAmount)}</div>
                    <div class="savings-amount-label">Saved</div>
                  </div>
                  <div class="savings-amount-item">
                    <div class="savings-amount-value">${Utils.formatCurrencyShort(goal.targetAmount)}</div>
                    <div class="savings-amount-label">Target</div>
                  </div>
                  <div class="savings-amount-item">
                    <div class="savings-amount-value">${Utils.formatCurrencyShort(Math.max(0, goal.targetAmount - goal.savedAmount))}</div>
                    <div class="savings-amount-label">Remaining</div>
                  </div>
                </div>
                <div class="progress-bar lg" style="margin-top:var(--space-4)">
                  <div class="progress-bar-fill ${pct >= 100 ? 'success' : ''}" style="width:${Math.min(pct, 100)}%"></div>
                </div>
                <div class="savings-card-actions">
                  <button class="btn btn-sm btn-outline" onclick="SavingsPage.addFunds(${goal.id})">+ Add Funds</button>
                  <button class="btn btn-sm btn-ghost" onclick="SavingsService.openModal(${JSON.stringify(goal).replace(/"/g, '&quot;')})">Edit</button>
                  <button class="btn btn-sm btn-ghost" style="color:var(--danger)" onclick="SavingsPage.deleteGoal(${goal.id})">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      `}
    `;
  },

  async addFunds(id) {
    const content = `
      <div class="form-group">
        <label class="form-label">Amount to add</label>
        <input type="number" class="form-input" id="add-funds-amount" placeholder="1000" min="1" autofocus>
      </div>
    `;
    const footer = `
      <button class="btn btn-secondary" data-close-modal>Cancel</button>
      <button class="btn btn-primary" id="add-funds-btn">Add</button>
    `;

    const overlay = Modal.open({ title: 'Add Funds', content, footer });
    overlay.querySelector('#add-funds-btn')?.addEventListener('click', async () => {
      const amount = overlay.querySelector('#add-funds-amount').value;
      if (!amount || parseFloat(amount) <= 0) { Toast.warning('Enter a valid amount'); return; }
      await SavingsService.addFunds(id, parseFloat(amount));
      Modal.close();
      Router.currentRoute = null;
      Router.handleRoute();
    });
  },

  async deleteGoal(id) {
    const result = await SavingsService.delete(id);
    if (result) {
      Router.currentRoute = null;
      Router.handleRoute();
    }
  }
};

/* ============================================
   SUBSCRIPTIONS PAGE — Subs & EMI
   ============================================ */

const SubscriptionsPage = {
  activeTab: 'subscriptions',

  async render(container) {
    const subs = await SubscriptionService.getAllSubs();
    const emis = await SubscriptionService.getAllEmis();

    container.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2 class="page-title">Subscriptions & EMI</h2>
          <p class="page-subtitle">Track recurring payments</p>
        </div>
        <div class="page-header-right">
          <button class="btn btn-primary" id="add-sub-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add ${this.activeTab === 'subscriptions' ? 'Subscription' : 'EMI'}
          </button>
        </div>
      </div>

      <div class="tabs">
        <button class="tab ${this.activeTab === 'subscriptions' ? 'active' : ''}" onclick="SubscriptionsPage.switchTab('subscriptions')">Subscriptions (${subs.length})</button>
        <button class="tab ${this.activeTab === 'emis' ? 'active' : ''}" onclick="SubscriptionsPage.switchTab('emis')">EMI Payments (${emis.length})</button>
      </div>

      <div id="sub-content">
        ${this.activeTab === 'subscriptions' ? this.renderSubs(subs) : this.renderEmis(emis)}
      </div>
    `;

    container.querySelector('#add-sub-btn')?.addEventListener('click', () => {
      if (this.activeTab === 'subscriptions') SubscriptionService.openSubModal();
      else SubscriptionService.openEmiModal();
    });
  },

  renderSubs(subs) {
    if (subs.length === 0) {
      return `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
          <h3 class="empty-state-title">No subscriptions yet</h3>
          <p class="empty-state-text">Track your recurring subscriptions here.</p>
        </div>
      `;
    }
    const monthly = subs.filter(s => s.isActive).reduce((sum, s) => sum + (s.amount || 0), 0);
    return `
      <div class="card" style="margin-bottom:var(--space-5);display:flex;align-items:center;justify-content:space-between">
        <div>
          <div style="font-size:var(--text-sm);color:var(--text-tertiary)">Monthly total</div>
          <div style="font-size:var(--text-2xl);font-weight:var(--weight-bold)">${Utils.formatCurrency(monthly)}</div>
        </div>
        <div class="badge badge-accent">${subs.filter(s => s.isActive).length} active</div>
      </div>
      <div class="sub-grid stagger-children">
        ${subs.map(sub => {
          const daysUntil = Utils.daysUntil(sub.nextDueDate);
          const isOverdue = daysUntil < 0;
          return `
            <div class="sub-card ${isOverdue ? 'sub-overdue' : ''}">
              <div class="sub-card-header">
                <div class="sub-card-left">
                  <div class="sub-card-icon" style="${isOverdue ? 'background:var(--danger-light);color:var(--danger)' : ''}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></svg>
                  </div>
                  <div>
                    <div class="sub-card-name">${Utils.escapeHtml(sub.name)}</div>
                    <div class="sub-card-cycle">${sub.billingCycle || 'Monthly'}</div>
                  </div>
                </div>
                <div class="sub-card-amount">${Utils.formatCurrency(sub.amount)}</div>
              </div>
              <div class="sub-card-details">
                <div class="sub-detail-row">
                  <span class="sub-detail-label">Next Due</span>
                  <span class="sub-detail-value" style="${isOverdue ? 'color:var(--danger)' : ''}">${isOverdue ? 'Overdue!' : (sub.nextDueDate ? Utils.formatDate(sub.nextDueDate) : '—')}</span>
                </div>
                <div class="sub-detail-row">
                  <span class="sub-detail-label">Status</span>
                  <span class="badge ${sub.isActive ? 'badge-success' : 'badge-default'}">${sub.isActive ? 'Active' : 'Paused'}</span>
                </div>
              </div>
              <div style="display:flex;gap:var(--space-2);margin-top:var(--space-3)">
                <button class="btn btn-sm btn-ghost" onclick="SubscriptionService.openSubModal(${JSON.stringify(sub).replace(/"/g, '&quot;')})">Edit</button>
                <button class="btn btn-sm btn-ghost" style="color:var(--danger)" onclick="SubscriptionsPage.deleteSub(${sub.id})">Delete</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  renderEmis(emis) {
    if (emis.length === 0) {
      return `
        <div class="empty-state">
          <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
          <h3 class="empty-state-title">No EMI payments yet</h3>
          <p class="empty-state-text">Track your EMI payments and installments here.</p>
        </div>
      `;
    }
    return `
      <div class="sub-grid stagger-children">
        ${emis.map(emi => {
          const pct = emi.totalInstallments > 0 ? Utils.percentage(emi.totalInstallments - emi.remainingInstallments, emi.totalInstallments) : 0;
          const isOverdue = Utils.daysUntil(emi.nextDueDate) < 0;
          return `
            <div class="sub-card ${isOverdue ? 'sub-overdue' : ''}">
              <div class="sub-card-header">
                <div class="sub-card-left">
                  <div class="sub-card-icon" style="${isOverdue ? 'background:var(--danger-light);color:var(--danger)' : ''}">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                  </div>
                  <div>
                    <div class="sub-card-name">${Utils.escapeHtml(emi.name)}</div>
                    <div class="sub-card-cycle">${Utils.formatCurrency(emi.emiAmount)}/month</div>
                  </div>
                </div>
                <div class="sub-card-amount">${Utils.formatCurrency(emi.totalAmount)}</div>
              </div>
              <div class="progress-bar" style="margin:var(--space-3) 0">
                <div class="progress-bar-fill" style="width:${pct}%"></div>
              </div>
              <div class="sub-card-details">
                <div class="sub-detail-row"><span class="sub-detail-label">Paid</span><span class="sub-detail-value">${Utils.formatCurrency(emi.paidAmount)}</span></div>
                <div class="sub-detail-row"><span class="sub-detail-label">Remaining</span><span class="sub-detail-value">${emi.remainingInstallments} of ${emi.totalInstallments} installments</span></div>
                <div class="sub-detail-row"><span class="sub-detail-label">Next Due</span><span class="sub-detail-value" style="${isOverdue ? 'color:var(--danger)' : ''}">${isOverdue ? 'Overdue!' : (emi.nextDueDate ? Utils.formatDate(emi.nextDueDate) : '—')}</span></div>
              </div>
              <div style="display:flex;gap:var(--space-2);margin-top:var(--space-3)">
                <button class="btn btn-sm btn-ghost" onclick="SubscriptionService.openEmiModal(${JSON.stringify(emi).replace(/"/g, '&quot;')})">Edit</button>
                <button class="btn btn-sm btn-ghost" style="color:var(--danger)" onclick="SubscriptionsPage.deleteEmi(${emi.id})">Delete</button>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  },

  switchTab(tab) {
    this.activeTab = tab;
    Router.currentRoute = null;
    Router.handleRoute();
  },

  async deleteSub(id) {
    const result = await SubscriptionService.deleteSub(id);
    if (result) { Router.currentRoute = null; Router.handleRoute(); }
  },

  async deleteEmi(id) {
    const result = await SubscriptionService.deleteEmi(id);
    if (result) { Router.currentRoute = null; Router.handleRoute(); }
  }
};
