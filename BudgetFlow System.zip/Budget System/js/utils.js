/* ============================================
   UTILITIES — Formatters, Helpers, Generators
   ============================================ */

const Utils = {
  // Currency formatting
  formatCurrency(amount) {
    const num = parseFloat(amount) || 0;
    if (num % 1 === 0) {
      return '₹' + num.toLocaleString('en-IN');
    }
    return '₹' + num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },

  formatCurrencyShort(amount) {
    const num = parseFloat(amount) || 0;
    if (num >= 10000000) return '₹' + (num / 10000000).toFixed(1) + 'Cr';
    if (num >= 100000) return '₹' + (num / 100000).toFixed(1) + 'L';
    if (num >= 1000) return '₹' + (num / 1000).toFixed(1) + 'K';
    return '₹' + num.toFixed(0);
  },

  // Date formatting
  formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  },

  formatDateShort(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  },

  formatDateInput(dateStr) {
    if (!dateStr) return new Date().toISOString().split('T')[0];
    return new Date(dateStr).toISOString().split('T')[0];
  },

  formatTime(timeStr) {
    if (!timeStr) return '';
    const [h, m] = timeStr.split(':');
    const hr = parseInt(h);
    const ampm = hr >= 12 ? 'PM' : 'AM';
    return `${hr % 12 || 12}:${m} ${ampm}`;
  },

  formatDateTime(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', {
      day: 'numeric', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  },

  formatMonth(month, year) {
    const d = new Date(year, month - 1);
    return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
  },

  // ID generators
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
  },

  generateReceiptNumber() {
    const prefix = 'RCP';
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}-${timestamp}-${random}`;
  },

  generateTransactionId() {
    const prefix = 'TXN';
    const timestamp = Date.now().toString().slice(-8);
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `${prefix}${timestamp}${random}`;
  },

  // Debounce & Throttle
  debounce(fn, delay = 300) {
    let timer;
    return function (...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  },

  throttle(fn, limit = 100) {
    let inThrottle;
    return function (...args) {
      if (!inThrottle) {
        fn.apply(this, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  },

  // Simple hash for PIN
  async hashPin(pin) {
    const encoder = new TextEncoder();
    const data = encoder.encode(pin + 'budget_salt_2024');
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  // Days until date
  daysUntil(dateStr) {
    if (!dateStr) return Infinity;
    const target = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    target.setHours(0, 0, 0, 0);
    return Math.ceil((target - today) / (1000 * 60 * 60 * 24));
  },

  // Get current month/year
  getCurrentMonth() {
    return new Date().getMonth() + 1;
  },

  getCurrentYear() {
    return new Date().getFullYear();
  },

  // Get start/end of month
  getMonthStart(month, year) {
    return new Date(year, month - 1, 1).toISOString().split('T')[0];
  },

  getMonthEnd(month, year) {
    return new Date(year, month, 0).toISOString().split('T')[0];
  },

  // Calculate percentage
  percentage(value, total) {
    if (!total) return 0;
    return Math.min(Math.round((value / total) * 100), 100);
  },

  // Escape HTML
  escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },

  // Get category icon SVG
  getCategoryIcon(iconKey) {
    return CATEGORY_ICONS[iconKey] || CATEGORY_ICONS.other;
  },

  getSavingsIcon(iconKey) {
    return SAVINGS_ICONS[iconKey] || SAVINGS_ICONS.piggybank;
  },

  // File to base64
  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  },

  // Download file
  downloadFile(content, filename, type = 'application/json') {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  // Download blob
  downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  // Today's date string
  today() {
    return new Date().toISOString().split('T')[0];
  },

  // Current time string
  currentTime() {
    return new Date().toTimeString().slice(0, 5);
  },

  // Color with opacity
  colorWithAlpha(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
};
