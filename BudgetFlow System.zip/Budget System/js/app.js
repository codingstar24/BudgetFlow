/* ============================================
   APP — Main Initialization
   ============================================ */

const App = {
  async init() {
    try {
      // Initialize database
      await initDB();

      // Initialize theme
      Theme.init();

      // Initialize toast
      Toast.init();

      // Render layout components
      Sidebar.render();
      Topbar.render();

      // Update theme toggle icon
      Theme.updateToggleIcon();

      // Register routes
      Router.register('dashboard', (c) => DashboardPage.render(c));
      Router.register('transactions', (c) => TransactionsPage.render(c));
      Router.register('categories', (c) => CategoriesPage.render(c));
      Router.register('budget', (c) => BudgetPage.render(c));
      Router.register('savings', (c) => SavingsPage.render(c));
      Router.register('subscriptions', (c) => SubscriptionsPage.render(c));
      Router.register('reports', (c) => ReportsPage.render(c));
      Router.register('trash', (c) => TrashPage.render(c));
      Router.register('settings', (c) => SettingsPage.render(c));

      // Initialize router
      Router.init();

      // Mobile sidebar overlay
      document.getElementById('sidebar-overlay')?.addEventListener('click', () => {
        document.getElementById('sidebar')?.classList.remove('mobile-open');
        document.getElementById('sidebar-overlay')?.classList.remove('visible');
      });

      // PIN lock check
      if (SecurityService.isPinEnabled()) {
        SecurityService.showLockScreen();
        this.initPinInput();
      }

      // Session timeout
      SecurityService.initSessionTimeout();

      console.log('BudgetFlow initialized successfully');
    } catch (err) {
      console.error('App initialization failed:', err);
    }
  },

  initPinInput() {
    const digits = document.querySelectorAll('#lock-screen .pin-digit');
    if (!digits.length) return;

    digits[0]?.focus();

    digits.forEach((input, i) => {
      input.addEventListener('input', async () => {
        if (input.value && i < 3) {
          digits[i + 1]?.focus();
        }

        // Check PIN when all 4 digits entered
        if (i === 3 && input.value) {
          const pin = Array.from(digits).map(d => d.value).join('');
          if (pin.length === 4) {
            const valid = await SecurityService.verifyPin(pin);
            if (valid) {
              SecurityService.hideLockScreen();
              SecurityService.initSessionTimeout();
            } else {
              document.getElementById('pin-error').textContent = 'Incorrect PIN';
              digits.forEach(d => { d.value = ''; d.style.borderColor = 'var(--danger)'; });
              digits[0]?.focus();
              setTimeout(() => {
                digits.forEach(d => d.style.borderColor = '');
                document.getElementById('pin-error').textContent = '';
              }, 1500);
            }
          }
        }
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !input.value && i > 0) {
          digits[i - 1]?.focus();
        }
      });
    });
  }
};

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => App.init());
